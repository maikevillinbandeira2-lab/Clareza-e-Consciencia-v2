import React, { useState, useRef } from 'react';
import { CalendarEventItem, CalendarEventType } from '../types';
import { XIcon, ImageIcon, LinkIcon, MusicIcon, PlusIcon, TrashIcon, FileTextIcon, AlertTriangleIcon } from './Icons';
import { getMoonPhase } from '../utils/moon';

interface CalendarEventModalProps {
  date: Date;
  events: CalendarEventItem[];
  onSave: (events: CalendarEventItem[]) => void;
  onClose: () => void;
}

const AddItemForm: React.FC<{onAddItem: (item: CalendarEventItem) => void}> = ({ onAddItem }) => {
    const [type, setType] = useState<CalendarEventType | null>(null);
    const [link, setLink] = useState('');
    const [title, setTitle] = useState('');
    const [noteContent, setNoteContent] = useState('');
    const imageInputRef = useRef<HTMLInputElement>(null);
    const audioInputRef = useRef<HTMLInputElement>(null);
    
    const MAX_FILE_SIZE_MB = 1;
    const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, fileType: 'image' | 'audio') => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            
            if (file.size > MAX_FILE_SIZE_BYTES) {
                alert(`O arquivo é muito grande. O tamanho máximo para imagens e áudios é de ${MAX_FILE_SIZE_MB}MB.`);
                event.target.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const content = e.target?.result as string;
                onAddItem({
                    id: `evt-${Date.now()}`,
                    type: fileType,
                    content,
                    title: file.name,
                });
                resetForm();
            };
            reader.readAsDataURL(file);
            event.target.value = '';
        }
    };
    
    const handleAddLink = () => {
        let finalLink = link.trim();
        if (!finalLink) return;

        if (!/^https?:\/\//i.test(finalLink)) {
            finalLink = 'https://' + finalLink;
        }

        try {
            new URL(finalLink); // Validate URL
             onAddItem({
                id: `evt-${Date.now()}`,
                type: 'link',
                content: finalLink,
                title: title.trim() || finalLink,
            });
            resetForm();
        } catch (_) {
            alert('Por favor, insira um URL válido.');
        }
    };

    const handleAddNote = () => {
        if (!noteContent.trim()) return;
        onAddItem({
            id: `evt-${Date.now()}`,
            type: 'note',
            content: noteContent,
            title: title.trim() || 'Anotação',
        });
        resetForm();
    };
    
    const resetForm = () => {
        setType(null);
        setLink('');
        setTitle('');
        setNoteContent('');
    }

    if (type === 'link') {
        return (
            <div className="p-3 bg-[var(--color-bg-primary)] rounded-lg space-y-2">
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Título (opcional)" className="w-full bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]" />
                <input type="url" value={link} onChange={e => setLink(e.target.value)} placeholder="www.exemplo.com" className="w-full bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]" />
                <div className="flex justify-end gap-2">
                    <button type="button" onClick={resetForm} className="px-3 py-1 text-xs rounded-md bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)]">Cancelar</button>
                    <button type="button" onClick={handleAddLink} className="px-3 py-1 text-xs font-semibold rounded-md bg-[var(--color-accent)] text-[var(--color-bg-primary)] hover:opacity-90">Adicionar Link</button>
                </div>
            </div>
        )
    }

    if (type === 'note') {
        return (
            <div className="p-3 bg-[var(--color-bg-primary)] rounded-lg space-y-2">
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Título (opcional)" className="w-full bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]" />
                <textarea value={noteContent} onChange={e => setNoteContent(e.target.value)} placeholder="Escreva sua anotação aqui..." className="w-full h-24 bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"></textarea>
                <div className="flex justify-end gap-2">
                    <button type="button" onClick={resetForm} className="px-3 py-1 text-xs rounded-md bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)]">Cancelar</button>
                    <button type="button" onClick={handleAddNote} className="px-3 py-1 text-xs font-semibold rounded-md bg-[var(--color-accent)] text-[var(--color-bg-primary)] hover:opacity-90">Adicionar Anotação</button>
                </div>
            </div>
        )
    }

    return (
        <div className="flex justify-around items-center p-3 bg-[var(--color-bg-primary)] rounded-lg">
            <button onClick={() => imageInputRef.current?.click()} className="flex flex-col items-center gap-1 text-[var(--color-text-secondary)] hover:text-[var(--color-accent-text)] transition-colors">
                <ImageIcon className="w-6 h-6"/> <span className="text-xs font-medium">Imagem</span>
            </button>
             <button onClick={() => audioInputRef.current?.click()} className="flex flex-col items-center gap-1 text-[var(--color-text-secondary)] hover:text-[var(--color-accent-text)] transition-colors">
                <MusicIcon className="w-6 h-6"/> <span className="text-xs font-medium">Áudio</span>
            </button>
             <button onClick={() => setType('link')} className="flex flex-col items-center gap-1 text-[var(--color-text-secondary)] hover:text-[var(--color-accent-text)] transition-colors">
                <LinkIcon className="w-6 h-6"/> <span className="text-xs font-medium">Link</span>
            </button>
            <button onClick={() => setType('note')} className="flex flex-col items-center gap-1 text-[var(--color-text-secondary)] hover:text-[var(--color-accent-text)] transition-colors">
                <FileTextIcon className="w-6 h-6"/> <span className="text-xs font-medium">Anotação</span>
            </button>
            <input type="file" ref={imageInputRef} onChange={(e) => handleFileChange(e, 'image')} accept="image/*" className="hidden" />
            <input type="file" ref={audioInputRef} onChange={(e) => handleFileChange(e, 'audio')} accept="audio/*" className="hidden" />
        </div>
    );
};


export default function CalendarEventModal({ date, events, onSave, onClose }: CalendarEventModalProps): React.ReactElement {
  const [localEvents, setLocalEvents] = useState<CalendarEventItem[]>(events);
  const [showAddForm, setShowAddForm] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  const moonPhase = getMoonPhase(date);

  const handleAddItem = (item: CalendarEventItem) => {
    setLocalEvents(prev => [...prev, item]);
    setShowAddForm(false);
  };
  
  const confirmDeleteItem = () => {
    if (pendingDeleteId) {
        setLocalEvents(prev => prev.filter(item => item.id !== pendingDeleteId));
        setPendingDeleteId(null);
    }
  }

  const handleSaveChanges = () => {
    onSave(localEvents);
    onClose();
  };

  const EventItemDisplay: React.FC<{item: CalendarEventItem}> = ({ item }) => {
    return (
      <div className="relative group bg-[var(--color-bg-tertiary)] p-3 rounded-lg flex items-start gap-4">
        {item.type === 'image' && <ImageIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'link' && <LinkIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'audio' && <MusicIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'note' && <FileTextIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}

        <div className="flex-grow overflow-hidden">
          {item.type === 'image' && <img src={item.content} className="max-h-40 rounded" alt="Item do calendário" />}
          {item.type === 'link' && <a href={item.content} target="_blank" rel="noopener noreferrer" className="text-[var(--color-accent-text-faded)] hover:underline truncate block">{item.title || item.content}</a>}
          {item.type === 'audio' && (
              <div>
                  <p className="text-sm text-[var(--color-text-primary)] truncate">{item.title}</p>
                  <audio controls src={item.content} className="w-full h-8 mt-1"></audio>
              </div>
          )}
          {item.type === 'note' && (
              <div>
                  <p className="text-sm font-semibold text-[var(--color-text-primary)]">{item.title || 'Anotação'}</p>
                  <p className="text-sm text-[var(--color-text-secondary)] mt-1 whitespace-pre-wrap">{item.content}</p>
              </div>
          )}
        </div>
        <button onClick={() => setPendingDeleteId(item.id)} className="absolute top-2 right-2 p-1.5 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 hover:bg-red-500 transition-all duration-300">
            <TrashIcon className="w-4 h-4"/>
        </button>
      </div>
    );
  };

  return (
    <div
      className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="bg-[var(--color-bg-secondary)] w-full max-w-lg max-h-[90vh] rounded-2xl shadow-2xl p-6 flex flex-col relative"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex-shrink-0 flex justify-between items-start pb-4 border-b border-[var(--color-border)]">
          <div>
            <h2 className="text-xl font-bold text-[var(--color-text-primary)]">
              {date.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
            </h2>
            <div className="flex items-center gap-2 mt-1 text-[var(--color-text-secondary)]">
                <moonPhase.icon className="w-4 h-4" />
                <span className="text-sm">{moonPhase.name}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)]"
            aria-label="Fechar"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-grow overflow-y-auto pr-2 -mr-4 my-6 space-y-3">
            {localEvents.map(item => <EventItemDisplay key={item.id} item={item} />)}
            {localEvents.length === 0 && !showAddForm && (
                <div className="text-center py-8 text-[var(--color-text-secondary)]">
                    <p>Nenhum item para este dia.</p>
                </div>
            )}

            {showAddForm ? (
                <AddItemForm onAddItem={handleAddItem} />
            ) : (
                <button onClick={() => setShowAddForm(true)} className="w-full mt-2 flex items-center justify-center gap-2 text-sm font-medium py-2 px-4 rounded-md text-[var(--color-accent-text)] border-2 border-dashed border-[var(--color-border)] hover:bg-[var(--color-accent-bg-subtle)] hover:border-[var(--color-accent)] transition-colors">
                    <PlusIcon className="w-5 h-5" />
                    Adicionar Item
                </button>
            )}
        </div>

        <div className="flex-shrink-0 flex justify-end items-center pt-4 border-t border-[var(--color-border)] gap-3">
          <button onClick={onClose} className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)]">
            Cancelar
          </button>
          <button onClick={handleSaveChanges} className="px-4 py-2 rounded-md text-sm font-semibold bg-[var(--color-accent)] text-[var(--color-bg-primary)] hover:opacity-90">
            Salvar Alterações
          </button>
        </div>
      </div>
      {pendingDeleteId && (
        <div 
            className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
        >
            <div className="bg-[var(--color-bg-primary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                    <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
                    Tem certeza de que deseja remover este item? Esta ação não pode ser desfeita.
                </p>
                <div className="mt-6 flex justify-center gap-3">
                    <button 
                        onClick={() => setPendingDeleteId(null)} 
                        className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={confirmDeleteItem} 
                        className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
                    >
                        Excluir
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}