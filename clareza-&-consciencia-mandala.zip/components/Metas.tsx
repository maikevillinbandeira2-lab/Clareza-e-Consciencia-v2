import React, { useState, useRef } from 'react';
import { MetasState, MetaEntry, StarImportance } from '../types';
import { PlusIcon, TrashIcon, CheckIcon, PencilIcon, AlertTriangleIcon, StarIcon, XIcon, LayoutGridIcon, LayoutListIcon } from './Icons';
import { POST_IT_COLORS, POST_IT_TEXT_COLORS } from '../data';
import HelpTooltip from './HelpTooltip';
import useLocalStorage from '../hooks/useLocalStorage';

interface MetasProps {
  metas: MetasState;
  onUpdate: (newState: MetasState) => void;
}

const ColorPicker: React.FC<{
    selectedColor: string;
    onSelectColor: (color: string) => void;
    className?: string;
}> = ({ selectedColor, onSelectColor, className = '' }) => (
    <div className={`flex items-center justify-between ${className}`}>
        <span className="text-sm text-[var(--color-text-secondary)]">Cor:</span>
        <div className="flex flex-wrap gap-2 justify-end">
            {POST_IT_COLORS.map(color => (
                <button
                    key={color}
                    type="button"
                    onClick={() => onSelectColor(color)}
                    className={`w-6 h-6 rounded-full transition-transform hover:scale-110 focus:outline-none border ${selectedColor === color ? 'ring-2 ring-offset-2 ring-offset-[var(--color-bg-secondary)] ring-[var(--color-accent)]' : 'border-black/10'}`}
                    style={{ backgroundColor: color }}
                    aria-label={`Selecionar cor ${color}`}
                />
            ))}
        </div>
    </div>
);

const StarPicker: React.FC<{
    selected: StarImportance | undefined;
    onSelect: (importance: StarImportance | undefined) => void;
    className?: string;
}> = ({ selected, onSelect, className = '' }) => {
    const [hovered, setHovered] = useState<number>(0);
    return (
        <div className={`flex items-center justify-between ${className}`}>
            <span className="text-sm text-[var(--color-text-secondary)]">Importância:</span>
            <div className="flex items-center gap-2">
                 {[1, 2, 3].map(level => (
                    <button
                        key={level}
                        type="button"
                        onMouseEnter={() => setHovered(level)}
                        onMouseLeave={() => setHovered(0)}
                        onClick={() => onSelect(selected === level ? undefined : level as StarImportance)}
                        className="p-1 rounded-full transition-all duration-200"
                        title={`${level} Estrela(s)`}
                    >
                        <StarIcon className={`w-6 h-6 transition-opacity ${(hovered >= level || (selected || 0) >= level) ? 'opacity-100' : 'opacity-40'}`} />
                    </button>
                ))}
            </div>
        </div>
    );
};

const AddMetaModal: React.FC<{
    onAdd: (text: string, color: string, importance?: StarImportance) => void;
    onClose: () => void;
}> = ({ onAdd, onClose }) => {
    const [text, setText] = useState('');
    const [selectedColor, setSelectedColor] = useState(POST_IT_COLORS[2]);
    const [importance, setImportance] = useState<StarImportance | undefined>();

    const handleAdd = () => {
        if (!text.trim()) return;
        onAdd(text.trim(), selectedColor, importance);
    };

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
                 <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-[var(--color-text-primary)]">Nova Meta</h3>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><XIcon className="w-5 h-5"/></button>
                </div>
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Qual sua próxima grande meta?"
                    className="w-full h-32 bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-[var(--color-text-primary)] resize-none focus:outline-none p-3 rounded-md placeholder:text-[var(--color-text-secondary)]"
                    autoFocus
                />
                <div className="space-y-3 mt-4">
                  <ColorPicker selectedColor={selectedColor} onSelectColor={setSelectedColor} />
                  <StarPicker selected={importance} onSelect={setImportance} />
                </div>
                <div className="flex items-center justify-end gap-2 mt-4">
                     <button onClick={onClose} className="text-sm py-2 px-4 rounded-md hover:bg-[var(--color-bg-tertiary)] transition-colors">Cancelar</button>
                    <button
                        onClick={handleAdd}
                        disabled={!text.trim()}
                        className="flex items-center justify-center gap-2 text-sm font-semibold py-2 px-4 rounded-md text-[var(--color-bg-primary)] bg-[var(--color-accent)] hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
                    >
                        <PlusIcon className="w-5 h-5" />
                        Adicionar
                    </button>
                </div>
            </div>
        </div>
    );
};


const MetaCard: React.FC<{
    meta: MetaEntry;
    onUpdate: (id: string, newValues: { text: string; color: string; importance?: StarImportance }) => void;
    onDelete: (id: string) => void;
}> = ({ meta, onUpdate, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState(meta.text);
    const [editColor, setEditColor] = useState(meta.color);
    const [editImportance, setEditImportance] = useState(meta.importance);

    const handleSave = () => {
        if (editText.trim()) {
            onUpdate(meta.id, { text: editText.trim(), color: editColor, importance: editImportance });
            setIsEditing(false);
        }
    };

    const textColor = POST_IT_TEXT_COLORS[isEditing ? editColor : meta.color] || 'text-gray-800';

    return (
        <div 
            className="p-4 rounded-lg shadow-lg flex flex-col h-56 transition-all duration-200 cursor-grab"
            style={{ 
                backgroundColor: isEditing ? editColor : meta.color,
            }}
        >
            {isEditing ? (
                <div className="flex-grow flex flex-col">
                    <textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        className={`flex-grow w-full bg-transparent border border-black/20 rounded-md p-2 resize-none focus:ring-1 focus:ring-black/40 focus:outline-none ${textColor}`}
                        rows={4}
                        autoFocus
                    />
                     <div className="space-y-2 mt-2">
                        <ColorPicker selectedColor={editColor} onSelectColor={setEditColor}/>
                        <StarPicker selected={editImportance} onSelect={setEditImportance} />
                    </div>
                </div>
            ) : (
                <div className="flex-grow flex flex-col justify-center">
                   {meta.importance && (
                       <div className="flex items-center justify-center mb-2 gap-1">
                           {[...Array(meta.importance)].map((_, i) => (
                               <StarIcon key={i} className="w-5 h-5" />
                           ))}
                       </div>
                   )}
                   <p className={`whitespace-pre-wrap font-medium text-lg text-center leading-relaxed ${textColor} p-2`}>
                        {meta.text}
                    </p>
                </div>
            )}
            <div className="flex justify-end items-center mt-3 gap-1 flex-shrink-0">
                {isEditing ? (
                    <>
                        <button onClick={() => setIsEditing(false)} className={`text-sm py-1 px-3 rounded-md hover:bg-black/10 ${textColor}`}>Cancelar</button>
                        <button onClick={handleSave} className={`text-sm font-semibold py-1 px-3 rounded-md bg-black/20 hover:bg-black/30 flex items-center gap-1 ${textColor}`}>
                            <CheckIcon className="w-4 h-4" /> Salvar
                        </button>
                    </>
                ) : (
                    <>
                        <button onClick={() => { setIsEditing(true); setEditText(meta.text); setEditColor(meta.color); setEditImportance(meta.importance) }} className={`p-2 rounded-full hover:bg-black/10 ${textColor}`}>
                            <PencilIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => onDelete(meta.id)} className={`p-2 rounded-full hover:bg-black/10 ${textColor}`}>
                            <TrashIcon className="w-4 h-4" />
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};


export default function Metas({ metas, onUpdate }: MetasProps): React.ReactElement {
    const [pendingDelete, setPendingDelete] = useState<MetaEntry | null>(null);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [layout, setLayout] = useLocalStorage<'single' | 'grid'>('metasLayout', 'single');


    // Drag and Drop state
    const dragItem = useRef<number | null>(null);
    const dragOverItem = useRef<number | null>(null);

    const handleDragStart = (index: number) => {
        dragItem.current = index;
    };

    const handleDragEnter = (index: number) => {
        dragOverItem.current = index;
    };

    const handleDragEnd = () => {
        if (dragItem.current === null || dragOverItem.current === null) return;
        
        const newMetas = [...metas];
        const draggedItemContent = newMetas.splice(dragItem.current, 1)[0];
        newMetas.splice(dragOverItem.current, 0, draggedItemContent);
        
        dragItem.current = null;
        dragOverItem.current = null;
        onUpdate(newMetas);
    };


    const handleAdd = (text: string, color: string, importance?: StarImportance) => {
        const newMeta: MetaEntry = {
            id: `meta-${Date.now()}`,
            text,
            color,
            importance,
        };
        onUpdate([newMeta, ...metas]);
        setIsAddModalOpen(false);
    };

    const handleUpdate = (id: string, newValues: { text: string; color: string; importance?: StarImportance }) => {
        onUpdate(metas.map(m => m.id === id ? { ...m, ...newValues } : m));
    };

    const handleDelete = (id: string) => {
        const metaToDelete = metas.find(m => m.id === id);
        if (metaToDelete) {
            setPendingDelete(metaToDelete);
        }
    };

    const confirmDelete = () => {
        if (pendingDelete) {
            onUpdate(metas.filter(m => m.id !== pendingDelete.id));
            setPendingDelete(null);
        }
    };


    return (
        <div className="h-full flex flex-col pt-16 md:pt-0">
            <header className="flex-shrink-0 flex justify-between items-start">
                <div>
                    <div className="flex items-center gap-3">
                        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Quadro de Metas</h2>
                        <HelpTooltip
                        title="Exemplos de Metas"
                        examples={[
                            "Adquirir a habilidade de cozinhar 5 pratos saudáveis diferentes.",
                            "Adquirir o hábito de ler 10 páginas de um livro todas as noites."
                        ]}
                        />
                    </div>
                    <p className="mt-1 text-[var(--color-text-secondary)]">Visualize seus objetivos como post-its e mantenha o foco.</p>
                </div>
                <div className="flex items-center sm:hidden p-1 rounded-lg bg-[var(--color-bg-tertiary)]">
                    <button
                        onClick={() => setLayout('single')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'single' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em lista"
                    >
                        <LayoutListIcon className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setLayout('grid')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'grid' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em grade"
                    >
                        <LayoutGridIcon className="w-5 h-5" />
                    </button>
                </div>
            </header>

            <div className="flex-grow mt-6 overflow-y-auto pr-2 -mr-2">
                <div className={`grid ${layout === 'grid' ? 'grid-cols-2' : 'grid-cols-1'} sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6`}>
                    {metas.map((meta, index) => (
                        <div
                            key={meta.id}
                            draggable
                            onDragStart={() => handleDragStart(index)}
                            onDragEnter={() => handleDragEnter(index)}
                            onDragEnd={handleDragEnd}
                            onDragOver={(e) => e.preventDefault()}
                        >
                            <MetaCard meta={meta} onUpdate={handleUpdate} onDelete={handleDelete} />
                        </div>
                    ))}
                </div>

                 {metas.length === 0 && (
                    <div className="text-center py-10 text-[var(--color-text-secondary)] col-span-full">
                        <p>Seu quadro de metas está pronto para ser preenchido.</p>
                        <p className="text-sm">Clique no botão '+' para adicionar seu primeiro objetivo.</p>
                    </div>
                )}
            </div>
            
            <button
                onClick={() => setIsAddModalOpen(true)}
                className="fixed bottom-8 right-8 w-16 h-16 bg-[var(--color-accent)] text-[var(--color-bg-primary)] rounded-full shadow-lg hover:opacity-90 transition-opacity flex items-center justify-center z-30"
                aria-label="Adicionar Nova Meta"
            >
                <PlusIcon className="w-8 h-8"/>
            </button>
            
            {isAddModalOpen && <AddMetaModal onAdd={handleAdd} onClose={() => setIsAddModalOpen(false)} />}

             {pendingDelete && (
                <div 
                    className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
                    role="dialog"
                    aria-modal="true"
                >
                    <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                            <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                        </div>
                        <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                        <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
                            Tem certeza que deseja excluir esta meta?
                        </p>
                        <div className="mt-6 flex justify-center gap-3">
                            <button 
                                onClick={() => setPendingDelete(null)} 
                                className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={confirmDelete} 
                                className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
                            >
                                Excluir
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}