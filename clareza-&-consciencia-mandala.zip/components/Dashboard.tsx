import React, { useState, useEffect } from 'react';
import { Category, CheckedState, Frequency, Activity } from '../types';
import ProgressBar from './ProgressBar';
import { PencilIcon, TrashIcon, PlusIcon, LockClosedIcon, LockOpenIcon } from './Icons';
import HelpTooltip from './HelpTooltip';

interface DashboardProps {
  category: Category;
  checkedState: CheckedState;
  onCheck: (activityId: string, key: string, isIncrement: boolean, frequency: Frequency) => void;
  onUpdateCategoryActivities: (categoryId: string, newActivities: Activity[]) => void;
  currentTheme: string;
}

// Helper to get all days in the current month
const getDaysInMonth = (date: Date) => {
  const year = date.getFullYear();
  const month = date.getMonth();
  const days = new Date(year, month + 1, 0).getDate();
  return Array.from({ length: days }, (_, i) => new Date(year, month, i + 1));
};

const ActivityTracker: React.FC<{
    title: string;
    activities: Activity[];
    checkedState: CheckedState;
    onCheck: (activityId: string, key: string, isIncrement: boolean, frequency: Frequency) => void;
    onUpdate: (updatedActivities: Activity[]) => void;
}> = ({ title, activities, checkedState, onCheck, onUpdate }) => {
    
    const [isEditing, setIsEditing] = useState(false);
    const [isCorrectionMode, setIsCorrectionMode] = useState(false);
    const [editedActivities, setEditedActivities] = useState<Activity[]>(activities);

    useEffect(() => {
        setEditedActivities(activities);
    }, [activities]);

    const today = new Date();
    const daysInMonth = getDaysInMonth(today);
    const currentDayKey = today.toISOString().split('T')[0];
    const currentMonthKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    
    const freq = activities.length > 0 ? activities[0].frequency : (title.includes('Diários') ? Frequency.DIARIO : title.includes('Semanais') ? Frequency.SEMANAL : Frequency.MENSAL);
    let headers: string[] = [];
    let keys: string[] = [];
    let currentWeekKey: string | null = null;
    
    if (freq === Frequency.DIARIO) {
        headers = daysInMonth.map(d => String(d.getDate()));
        keys = daysInMonth.map(d => d.toISOString().split('T')[0]);
    } else if (freq === Frequency.SEMANAL) {
        // This dynamic import is a placeholder. In a real app, you'd get the function from a shared util.
        // For now, we'll redefine it to avoid the circular dependency issue.
        const getWeek = (date: Date): number => {
            const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
            const dayNum = d.getUTCDay() || 7;
            d.setUTCDate(d.getUTCDate() + 4 - dayNum);
            const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
            return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
        };
        currentWeekKey = `${today.getFullYear()}-${getWeek(today)}`;
        const weeksInMonth = [...new Set(daysInMonth.map(d => `${d.getFullYear()}-${getWeek(d)}`))];
        headers = weeksInMonth.map((week) => `S${week.split('-')[1]}`);
        keys = weeksInMonth;
    } else if (freq === Frequency.MENSAL) {
        headers = [today.toLocaleString('default', { month: 'long' })];
        keys = [currentMonthKey];
    }
    
    const totalProgress = activities.reduce((acc, activity) => {
        const checks = checkedState[activity.id] || [];
        if (freq === Frequency.SEMANAL || freq === Frequency.MENSAL) {
            const target = activity.target || 1;
            const progressPerPeriod = keys.map(key => {
                const count = checks.filter(c => c === key).length;
                return Math.min(1, count / target);
            });
            return acc + (progressPerPeriod.reduce((sum, p) => sum + p, 0) / keys.length);
        }
        const relevantChecks = checks.filter(key => keys.includes(key)).length;
        return acc + (relevantChecks / keys.length);
    }, 0);

    const overallProgress = activities.length > 0 ? (totalProgress / activities.length) * 100 : 0;
    
    const handleActivityUpdate = (id: string, field: 'name' | 'target', value: string | number | undefined) => {
        setEditedActivities(current => current.map(a => a.id === id ? { ...a, [field]: value } : a));
    };

    const handleDelete = (id: string) => {
        setEditedActivities(current => current.filter(a => a.id !== id));
    };

    const handleAddActivity = () => {
        const newActivity: Activity = {
            id: `activity-${Date.now()}`,
            name: 'Nova Atividade',
            frequency: freq,
            ...((freq === Frequency.SEMANAL || freq === Frequency.MENSAL) && { target: 1 }),
        };
        setEditedActivities(current => [...current, newActivity]);
    };

    const handleEnterEditMode = () => {
        setIsCorrectionMode(false);
        setIsEditing(true);
    };

    const handleSave = () => {
        const validatedActivities = editedActivities.map(a => ({
            ...a,
            target: a.target ?? 1
        }));
        onUpdate(validatedActivities);
        setIsEditing(false);
        setIsCorrectionMode(false);
    };

    const handleCancel = () => {
        setEditedActivities(activities);
        setIsEditing(false);
        setIsCorrectionMode(false);
    };
    
    return (
        <div className="bg-[var(--color-bg-secondary)] rounded-xl p-4 md:p-6 shadow-lg transition-colors">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-[var(--color-text-primary)]">{title}</h3>
                {!isEditing && (
                    <div className="flex items-center gap-2">
                         <button 
                            onClick={() => setIsCorrectionMode(!isCorrectionMode)} 
                            className="text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] p-1 rounded-full hover:bg-[var(--color-bg-tertiary)] transition-colors"
                            aria-label={isCorrectionMode ? "Sair do modo de correção" : "Entrar no modo de correção"}
                            title={isCorrectionMode ? "Sair do modo de correção" : "Entrar no modo de correção"}
                         >
                            {isCorrectionMode ? <LockOpenIcon className="w-5 h-5" /> : <LockClosedIcon className="w-5 h-5" />}
                        </button>
                        <button onClick={handleEnterEditMode} className="text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] p-1 rounded-full hover:bg-[var(--color-bg-tertiary)] transition-colors" aria-label="Editar atividades">
                            <PencilIcon className="w-5 h-5" />
                        </button>
                    </div>
                )}
            </div>

            {isEditing ? (
                <div className="space-y-3">
                    {editedActivities.map((activity, index) => (
                        <div key={activity.id} className="flex items-center gap-3">
                           <input
                             type="text"
                             value={activity.name}
                             onChange={(e) => handleActivityUpdate(activity.id, 'name', e.target.value)}
                             className="flex-grow bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-[var(--color-text-primary)] text-sm rounded-md px-3 py-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                             autoFocus={index === editedActivities.length - 1 && activity.name === 'Nova Atividade'}
                           />
                           {(freq === Frequency.SEMANAL || freq === Frequency.MENSAL) && (
                                <div className="flex items-center gap-1 flex-shrink-0">
                                    <button
                                        type="button"
                                        onClick={() => handleActivityUpdate(activity.id, 'target', Math.max(1, (activity.target || 1) - 1))}
                                        className="w-8 h-8 flex items-center justify-center rounded-md text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] transition-colors text-lg"
                                        aria-label="Diminuir meta"
                                    >
                                        -
                                    </button>
                                   <input
                                     type="number"
                                     min="1"
                                     value={activity.target ?? ''}
                                     onChange={(e) => {
                                        const val = parseInt(e.target.value, 10);
                                        handleActivityUpdate(activity.id, 'target', !isNaN(val) && val > 0 ? val : undefined);
                                     }}
                                     onBlur={() => {
                                         if (activity.target === undefined) {
                                             handleActivityUpdate(activity.id, 'target', 1);
                                         }
                                     }}
                                     className="w-14 bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-[var(--color-text-primary)] text-sm rounded-md px-2 py-2 text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                   />
                                    <button
                                        type="button"
                                        onClick={() => handleActivityUpdate(activity.id, 'target', (activity.target || 0) + 1)}
                                        className="w-8 h-8 flex items-center justify-center rounded-md text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] transition-colors text-lg"
                                        aria-label="Aumentar meta"
                                    >
                                        +
                                    </button>
                                   <span className="text-sm text-[var(--color-text-secondary)] ml-1">
                                     {freq === Frequency.SEMANAL ? 'x/sem' : 'x/mês'}
                                   </span>
                               </div>
                           )}
                           <button onClick={() => handleDelete(activity.id)} className="p-2 text-[var(--color-text-secondary)] hover:text-red-500 hover:bg-[var(--color-bg-tertiary)] rounded-md transition-colors" aria-label={`Excluir ${activity.name}`}>
                               <TrashIcon className="w-5 h-5"/>
                           </button>
                        </div>
                    ))}
                    <button onClick={handleAddActivity} className="w-full mt-2 flex items-center justify-center gap-2 text-sm font-medium py-2 px-4 rounded-md text-[var(--color-accent-text)] hover:bg-[var(--color-accent-bg-subtle)] transition-colors">
                        <PlusIcon className="w-5 h-5" />
                        Adicionar Atividade
                    </button>
                    <div className="flex justify-end items-center gap-3 mt-4 pt-4 border-t border-[var(--color-border)]">
                        <button onClick={handleCancel} className="text-sm font-medium py-2 px-4 rounded-md text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] transition-colors">Cancelar</button>
                        <button onClick={handleSave} className="text-sm font-semibold py-2 px-4 rounded-md bg-[var(--color-accent)] text-[var(--color-bg-primary)] hover:opacity-90 transition-opacity">Salvar Alterações</button>
                    </div>
                </div>
            ) : (
                <>
                  {activities.length > 0 ? (
                    <>
                      <div className="mb-4">
                          <div className="flex justify-between items-center mb-1">
                              <span className="text-xs font-medium text-[var(--color-accent-text-faded)]">Progresso Geral</span>
                              <span className="text-xs font-medium text-[var(--color-accent-text-faded)]">{overallProgress.toFixed(0)}%</span>
                          </div>
                          <ProgressBar progress={overallProgress} />
                      </div>

                      <div className="overflow-x-auto">
                          <table className="w-full min-w-[700px] text-sm text-left">
                              <thead>
                                  <tr className="border-b border-[var(--color-border)]">
                                      <th className="py-2 pr-4 font-semibold text-[var(--color-text-tertiary)] w-1/3">Atividade</th>
                                      {headers.map(header => <th key={header} className={`${freq === Frequency.DIARIO ? 'w-10' : 'w-28'} h-10 text-center font-medium text-[var(--color-text-secondary)]`}>{header}</th>)}
                                      <th className="py-2 pl-4 font-semibold text-[var(--color-text-tertiary)] text-center">Evolução</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {activities.map(activity => {
                                      const checks = checkedState[activity.id] || [];
                                      let progress = 0;
                                      if(freq === Frequency.SEMANAL || freq === Frequency.MENSAL) {
                                          const target = activity.target || 1;
                                          const progressPerPeriod = keys.map(key => {
                                              const count = checks.filter(c => c === key).length;
                                              return Math.min(1, count / target);
                                          });
                                          progress = (progressPerPeriod.reduce((sum, p) => sum + p, 0) / keys.length) * 100;
                                      } else {
                                          const relevantChecks = checks.filter(key => keys.includes(key));
                                          progress = (relevantChecks.length / keys.length) * 100;
                                      }

                                      return (
                                          <tr key={activity.id} className="border-b border-[var(--color-border)] last:border-0">
                                              <td className="py-3 pr-4 text-[var(--color-text-primary)]">{activity.name}</td>
                                              {keys.map(key => {
                                                  const isCurrent = (freq === Frequency.DIARIO && key === currentDayKey) || (freq === Frequency.SEMANAL && key === currentWeekKey) || (freq === Frequency.MENSAL && key === currentMonthKey);
                                                  const isDisabled = !isCorrectionMode && !isCurrent;
                                                  
                                                  if(freq === Frequency.SEMANAL || freq === Frequency.MENSAL) {
                                                      const count = checks.filter(c => c === key).length;
                                                      const target = activity.target || 1;
                                                      const isDecrementDisabled = isDisabled || count === 0;
                                                      const isIncrementDisabled = isDisabled || count >= target;
                                                      
                                                      return (
                                                          <td key={key} className="w-28 text-center py-1">
                                                              <div className="flex items-center justify-center gap-1">
                                                                  <button onClick={() => onCheck(activity.id, key, false, freq)} disabled={isDecrementDisabled} className="p-1 rounded-full text-[var(--color-text-secondary)] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)] transition-colors">-</button>
                                                                  <span className="font-mono text-sm w-12 text-center text-[var(--color-text-primary)]">{count}/{target}</span>
                                                                  <button onClick={() => onCheck(activity.id, key, true, freq)} disabled={isIncrementDisabled} className="p-1 rounded-full text-[var(--color-text-secondary)] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)] transition-colors">+</button>
                                                              </div>
                                                          </td>
                                                      )
                                                  }

                                                  const isChecked = checks.includes(key);
                                                  return (
                                                      <td key={key} className="w-10 h-10 text-center">
                                                          <input
                                                              type="checkbox"
                                                              checked={isChecked}
                                                              onChange={(e) => onCheck(activity.id, key, e.target.checked, freq)}
                                                              disabled={isDisabled}
                                                              className={`w-5 h-5 rounded bg-transparent border-[var(--color-border-input)] text-[var(--color-accent)] focus:ring-[var(--color-accent)] focus:ring-2 ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                                                              aria-label={`Marcar ${activity.name} para ${key}`}
                                                          />
                                                      </td>
                                                  );
                                              })}
                                              <td className="py-2 pl-4 text-center">
                                                  <div className="flex items-center justify-center gap-2">
                                                      <div className="w-20">
                                                          <ProgressBar progress={progress} small />
                                                      </div>
                                                      <span className="text-xs text-[var(--color-text-secondary)] w-10">{progress.toFixed(0)}%</span>
                                                  </div>
                                              </td>
                                          </tr>
                                      );
                                  })}
                              </tbody>
                          </table>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-6 text-[var(--color-text-secondary)] border-2 border-dashed border-[var(--color-border)] rounded-lg">
                      <p className="text-sm font-medium">Nenhuma atividade definida.</p>
                      <p className="text-xs mt-1">
                          Clique no ícone <PencilIcon className="w-3 h-3 inline-block -mt-1 mx-1" aria-hidden="true" /> para começar.
                      </p>
                    </div>
                  )}
                </>
            )}
        </div>
    );
};


export default function Dashboard({ category, checkedState, onCheck, onUpdateCategoryActivities, currentTheme }: DashboardProps): React.ReactElement {
  const dailyActivities = category.activities.filter(a => a.frequency === Frequency.DIARIO);
  const weeklyActivities = category.activities.filter(a => a.frequency === Frequency.SEMANAL);
  const monthlyActivities = category.activities.filter(a => a.frequency === Frequency.MENSAL);

  const handleTrackerUpdate = (updatedFreqActivities: Activity[], frequency: Frequency) => {
    const otherActivities = category.activities.filter(a => a.frequency !== frequency);
    const newFullActivities = [...otherActivities, ...updatedFreqActivities].sort((a,b) => a.id.localeCompare(b.id)); // Keep a stable order
    onUpdateCategoryActivities(category.id, newFullActivities);
  };


  return (
    <div className="space-y-8 ml-0 md:ml-0 pt-16 md:pt-0">
       <header>
          <div className="flex items-center gap-3">
            <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">{category.name}</h2>
            {category.examples && category.examples.length > 0 && (
                <HelpTooltip
                    title={`Inspirações para ${category.name}`}
                    examples={category.examples}
                />
            )}
          </div>
          <p className="mt-1 text-[var(--color-text-secondary)]">Seu painel de controle para alta performance.</p>
       </header>
       
       <div className="space-y-6">
            <ActivityTracker title="Hábitos Diários" activities={dailyActivities} checkedState={checkedState} onCheck={onCheck} onUpdate={(updated) => handleTrackerUpdate(updated, Frequency.DIARIO)} />
            <ActivityTracker title="Metas Semanais" activities={weeklyActivities} checkedState={checkedState} onCheck={onCheck} onUpdate={(updated) => handleTrackerUpdate(updated, Frequency.SEMANAL)} />
            <ActivityTracker title="Objetivos Mensais" activities={monthlyActivities} checkedState={checkedState} onCheck={onCheck} onUpdate={(updated) => handleTrackerUpdate(updated, Frequency.MENSAL)} />
       </div>
    </div>
  );
}