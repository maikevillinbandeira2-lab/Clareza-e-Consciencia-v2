import React, { useState, useRef } from 'react';
import { ConquistasState, ConquistaEntry } from '../types';
import { PlusIcon, TrashIcon, PencilIcon, TrophyIcon, StarIcon, AlertTriangleIcon, LayoutGridIcon, LayoutListIcon } from './Icons';
import ConquistaModal from './ConquistaModal';
import { POST_IT_COLORS, POST_IT_TEXT_COLORS } from '../data';
import HelpTooltip from './HelpTooltip';
import useLocalStorage from '../hooks/useLocalStorage';

interface ConquistasProps {
  conquistas: ConquistasState;
  onUpdate: (newState: ConquistasState) => void;
}

const ConquistaCard: React.FC<{
    conquista: ConquistaEntry;
    onEdit: () => void;
    onDelete: () => void;
}> = ({ conquista, onEdit, onDelete }) => {
    const bgColor = conquista.color || POST_IT_COLORS[0];
    const textColor = POST_IT_TEXT_COLORS[bgColor] || 'text-slate-800';

    return (
        <div className="rounded-xl shadow-lg p-5 flex flex-col h-full min-h-[14rem] cursor-grab" style={{backgroundColor: bgColor}}>
            <div className="flex justify-between items-start">
                 <div className="flex-1">
                    <p className={`text-sm ${textColor} opacity-70`}>{new Date(conquista.date + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                    <div className="flex items-center gap-2 mt-1">
                      {conquista.importance && (
                          <div className="flex items-center flex-shrink-0">
                              {[...Array(conquista.importance)].map((_, i) => (
                                  <StarIcon key={i} className="w-5 h-5" />
                              ))}
                          </div>
                      )}
                      <h3 className={`text-xl font-bold ${textColor}`}>{conquista.title}</h3>
                    </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                    <button onClick={onEdit} className={`p-2 rounded-full ${textColor} opacity-70 hover:opacity-100 hover:bg-black/10`}><PencilIcon className="w-4 h-4" /></button>
                    <button onClick={onDelete} className={`p-2 rounded-full ${textColor} opacity-70 hover:opacity-100 hover:bg-black/10`}><TrashIcon className="w-4 h-4" /></button>
                </div>
            </div>
            <div className="flex-grow overflow-y-auto mt-3 space-y-3 -mr-2 pr-2">
                {conquista.description && (
                    <p className={`${textColor} opacity-90 whitespace-pre-wrap`}>{conquista.description}</p>
                )}
            </div>
        </div>
    );
};


export default function Conquistas({ conquistas, onUpdate }: ConquistasProps): React.ReactElement {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingConquista, setEditingConquista] = useState<ConquistaEntry | null>(null);
    const [pendingDelete, setPendingDelete] = useState<ConquistaEntry | null>(null);
    const [layout, setLayout] = useLocalStorage<'single' | 'grid'>('conquistasLayout', 'single');


    // Drag and Drop state
    const dragItem = useRef<number | null>(null);
    const dragOverItem = useRef<number | null>(null);

    const handleDragStart = (index: number) => {
        dragItem.current = index;
    };

    const handleDragEnter = (index: number) => {
        dragOverItem.current = index;
    };

    const handleDragEnd = () => {
        if (dragItem.current === null || dragOverItem.current === null) return;

        const newConquistas = [...conquistas];
        const draggedItemContent = newConquistas.splice(dragItem.current, 1)[0];
        newConquistas.splice(dragOverItem.current, 0, draggedItemContent);
        
        dragItem.current = null;
        dragOverItem.current = null;
        onUpdate(newConquistas);
    };

    const handleSave = (conquistaToSave: ConquistaEntry) => {
        const index = conquistas.findIndex(c => c.id === conquistaToSave.id);
        let newConquistas;
        if (index > -1) {
            newConquistas = [...conquistas];
            newConquistas[index] = conquistaToSave;
        } else {
            newConquistas = [conquistaToSave, ...conquistas];
        }
        onUpdate(newConquistas);
        setIsModalOpen(false);
        setEditingConquista(null);
    };

    const handleOpenModal = (conquista: ConquistaEntry | null) => {
        setEditingConquista(conquista);
        setIsModalOpen(true);
    };

    const confirmDelete = () => {
        if (pendingDelete) {
            onUpdate(conquistas.filter(c => c.id !== pendingDelete.id));
            setPendingDelete(null);
        }
    };

    return (
        <div className="h-full flex flex-col pt-16 md:pt-0 relative">
            <header className="flex-shrink-0 flex justify-between items-start">
                <div>
                    <div className="flex items-center gap-3">
                        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Mural de Conquistas</h2>
                        <HelpTooltip
                        title="Exemplos de Conquistas"
                        examples={[
                            "Consegui manter minha rotina de exercícios por 7 dias seguidos.",
                            "Adquiri o hábito de tomar café sem açúcar após 2 semanas de esforço."
                        ]}
                        />
                    </div>
                    <p className="mt-1 text-[var(--color-text-secondary)]">Celebre e registre seus marcos e vitórias.</p>
                </div>
                <div className="flex items-center sm:hidden p-1 rounded-lg bg-[var(--color-bg-tertiary)]">
                    <button
                        onClick={() => setLayout('single')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'single' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em lista"
                    >
                        <LayoutListIcon className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setLayout('grid')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'grid' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em grade"
                    >
                        <LayoutGridIcon className="w-5 h-5" />
                    </button>
                </div>
            </header>

            <div className="flex-grow mt-6 overflow-y-auto pr-2 -mr-2">
                 <div className={`grid ${layout === 'grid' ? 'grid-cols-2' : 'grid-cols-1'} sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6`}>
                    {conquistas.map((conquista, index) => (
                        <div
                            key={conquista.id}
                            draggable
                            onDragStart={() => handleDragStart(index)}
                            onDragEnter={() => handleDragEnter(index)}
                            onDragEnd={handleDragEnd}
                            onDragOver={(e) => e.preventDefault()}
                        >
                            <ConquistaCard 
                                conquista={conquista}
                                onEdit={() => handleOpenModal(conquista)}
                                onDelete={() => setPendingDelete(conquista)}
                            />
                        </div>
                    ))}
                 </div>
                 {conquistas.length === 0 && (
                    <div className="w-full col-span-full text-center p-4 mt-8">
                        <TrophyIcon className="mx-auto h-12 w-12 text-[var(--color-text-secondary)]" />
                        <h3 className="mt-4 text-lg font-medium text-[var(--color-text-primary)]">Seu Mural está Vazio</h3>
                        <p className="mt-1 text-sm text-[var(--color-text-secondary)]">Clique no botão '+' para adicionar sua primeira conquista!</p>
                    </div>
                )}
            </div>

            <button
                onClick={() => handleOpenModal(null)}
                className="fixed bottom-8 right-8 w-16 h-16 bg-[var(--color-accent)] text-[var(--color-bg-primary)] rounded-full shadow-lg hover:opacity-90 transition-opacity flex items-center justify-center z-30"
                aria-label="Adicionar Nova Conquista"
            >
                <PlusIcon className="w-8 h-8"/>
            </button>

            {isModalOpen && (
                <ConquistaModal
                    conquista={editingConquista}
                    onSave={handleSave}
                    onClose={() => {
                        setIsModalOpen(false);
                        setEditingConquista(null);
                    }}
                />
            )}

            {pendingDelete && (
                <div 
                    className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
                    role="dialog"
                    aria-modal="true"
                >
                    <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                            <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                        </div>
                        <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                        <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
                            Tem certeza de que deseja excluir a conquista "{pendingDelete.title}"?
                        </p>
                        <div className="mt-6 flex justify-center gap-3">
                            <button 
                                onClick={() => setPendingDelete(null)} 
                                className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={confirmDelete} 
                                className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
                            >
                                Excluir
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}