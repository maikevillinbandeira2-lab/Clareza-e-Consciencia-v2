import React, { useState, useRef } from 'react';
import { MantrasState, MantraEntry } from '../types';
import { PlusIcon, TrashIcon, CheckIcon, PencilIcon, AlertTriangleIcon, XIcon, LayoutGridIcon, LayoutListIcon } from './Icons';
import { POST_IT_COLORS, POST_IT_TEXT_COLORS } from '../data';
import HelpTooltip from './HelpTooltip';
import useLocalStorage from '../hooks/useLocalStorage';

interface MantrasProps {
  mantras: MantrasState;
  onUpdate: (newState: MantrasState) => void;
}

const ColorPicker: React.FC<{
    selectedColor: string;
    onSelectColor: (color: string) => void;
    className?: string;
}> = ({ selectedColor, onSelectColor, className = '' }) => (
    <div className={`flex items-center justify-between ${className}`}>
        <span className="text-sm text-[var(--color-text-secondary)]">Cor:</span>
        <div className="flex flex-wrap gap-2 justify-end">
            {POST_IT_COLORS.map(color => (
                <button
                    key={color}
                    type="button"
                    onClick={() => onSelectColor(color)}
                    className={`w-6 h-6 rounded-full transition-transform hover:scale-110 focus:outline-none border ${selectedColor === color ? 'ring-2 ring-offset-2 ring-offset-[var(--color-bg-secondary)] ring-[var(--color-accent)]' : 'border-black/10'}`}
                    style={{ backgroundColor: color }}
                    aria-label={`Selecionar cor ${color}`}
                />
            ))}
        </div>
    </div>
);

const MantraCard: React.FC<{
    mantra: MantraEntry;
    onUpdate: (id: string, newValues: { text: string; color: string }) => void;
    onDelete: (id: string) => void;
}> = ({ mantra, onUpdate, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState(mantra.text);
    const [editColor, setEditColor] = useState(mantra.color);

    const handleSave = () => {
        if (editText.trim()) {
            onUpdate(mantra.id, { text: editText.trim(), color: editColor });
            setIsEditing(false);
        }
    };

    const textColor = POST_IT_TEXT_COLORS[isEditing ? editColor : mantra.color] || 'text-gray-800';

    return (
        <div
            className="p-4 rounded-lg shadow-lg flex flex-col h-56 transition-all duration-200 cursor-grab"
            style={{ backgroundColor: isEditing ? editColor : mantra.color }}
        >
            {isEditing ? (
                <div className="flex-grow flex flex-col">
                    <textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        className={`flex-grow w-full bg-transparent border border-black/20 rounded-md p-2 resize-none focus:ring-1 focus:ring-black/40 focus:outline-none ${textColor}`}
                        rows={4}
                        autoFocus
                    />
                    <ColorPicker selectedColor={editColor} onSelectColor={setEditColor} className="mt-2" />
                </div>
            ) : (
                <p className={`flex-grow whitespace-pre-wrap font-serif text-lg leading-relaxed ${textColor} p-2`}>
                    {mantra.text}
                </p>
            )}
            <div className="flex justify-end items-center mt-3 gap-1 flex-shrink-0">
                {isEditing ? (
                    <>
                        <button onClick={() => setIsEditing(false)} className={`text-sm py-1 px-3 rounded-md hover:bg-black/10 ${textColor}`}>Cancelar</button>
                        <button onClick={handleSave} className={`text-sm font-semibold py-1 px-3 rounded-md bg-black/20 hover:bg-black/30 flex items-center gap-1 ${textColor}`}>
                            <CheckIcon className="w-4 h-4" /> Salvar
                        </button>
                    </>
                ) : (
                    <>
                        <button onClick={() => { setIsEditing(true); setEditText(mantra.text); setEditColor(mantra.color); }} className={`p-2 rounded-full hover:bg-black/10 ${textColor}`}>
                            <PencilIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => onDelete(mantra.id)} className={`p-2 rounded-full hover:bg-black/10 ${textColor}`}>
                            <TrashIcon className="w-4 h-4" />
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};

const AddMantraModal: React.FC<{
    onAdd: (text: string, color: string) => void;
    onClose: () => void;
}> = ({ onAdd, onClose }) => {
    const [text, setText] = useState('');
    const [selectedColor, setSelectedColor] = useState(POST_IT_COLORS[6]);

    const handleAdd = () => {
        if (!text.trim()) return;
        onAdd(text.trim(), selectedColor);
        setText('');
        setSelectedColor(POST_IT_COLORS[6]);
    };

    return (
        <div className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-[var(--color-text-primary)]">Novo Mantra</h3>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><XIcon className="w-5 h-5"/></button>
                </div>
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Escreva um novo mantra ou afirmação..."
                    className="w-full h-32 bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-[var(--color-text-primary)] resize-none focus:outline-none p-3 rounded-md placeholder:text-[var(--color-text-secondary)]"
                    autoFocus
                />
                <ColorPicker selectedColor={selectedColor} onSelectColor={setSelectedColor} className="my-4" />
                <div className="flex items-center justify-end gap-2 mt-2">
                    <button onClick={onClose} className="text-sm py-2 px-4 rounded-md hover:bg-[var(--color-bg-tertiary)] transition-colors">Cancelar</button>
                    <button
                        onClick={handleAdd}
                        disabled={!text.trim()}
                        className="flex items-center justify-center gap-2 text-sm font-semibold py-2 px-4 rounded-md text-[var(--color-bg-primary)] bg-[var(--color-accent)] hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
                    >
                        <PlusIcon className="w-5 h-5" />
                        Adicionar
                    </button>
                </div>
            </div>
        </div>
    );
};


export default function Mantras({ mantras, onUpdate }: MantrasProps): React.ReactElement {
    const [pendingDelete, setPendingDelete] = useState<MantraEntry | null>(null);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [layout, setLayout] = useLocalStorage<'single' | 'grid'>('mantrasLayout', 'single');


    // Drag and Drop state
    const dragItem = useRef<number | null>(null);
    const dragOverItem = useRef<number | null>(null);

    const handleDragStart = (index: number) => {
        dragItem.current = index;
    };

    const handleDragEnter = (index: number) => {
        dragOverItem.current = index;
    };

    const handleDragEnd = () => {
        if (dragItem.current === null || dragOverItem.current === null) return;
        
        const newMantras = [...mantras];
        const draggedItemContent = newMantras.splice(dragItem.current, 1)[0];
        newMantras.splice(dragOverItem.current, 0, draggedItemContent);
        
        dragItem.current = null;
        dragOverItem.current = null;
        onUpdate(newMantras);
    };

    const handleAdd = (text: string, color: string) => {
        const newMantra: MantraEntry = {
            id: `mantra-${Date.now()}`,
            text,
            color,
        };
        onUpdate([newMantra, ...mantras]);
        setIsAddModalOpen(false);
    };

    const handleUpdate = (id: string, newValues: { text: string; color: string }) => {
        onUpdate(mantras.map(m => (m.id === id ? { ...m, ...newValues } : m)));
    };

    const handleDelete = (id: string) => {
        const mantraToDelete = mantras.find(m => m.id === id);
        if (mantraToDelete) {
            setPendingDelete(mantraToDelete);
        }
    };

    const confirmDelete = () => {
        if (pendingDelete) {
            onUpdate(mantras.filter(m => m.id !== pendingDelete.id));
            setPendingDelete(null);
        }
    };

    return (
        <div className="h-full flex flex-col pt-16 md:pt-0">
            <header className="flex-shrink-0 flex justify-between items-start">
                <div>
                    <div className="flex items-center gap-3">
                        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Mantras e Afirmações</h2>
                        <HelpTooltip
                        title="Exemplos de Mantras"
                        examples={[
                            "Para autoconfiança: 'Eu sou capaz e merecedor(a) de todo o sucesso que desejo.'",
                            "Para calma e paciência: 'Eu respiro fundo e encontro paz no momento presente.'"
                        ]}
                        />
                    </div>
                    <p className="mt-1 text-[var(--color-text-secondary)]">Seu caderno de pensamentos positivos e intenções.</p>
                </div>
                <div className="flex items-center sm:hidden p-1 rounded-lg bg-[var(--color-bg-tertiary)]">
                    <button
                        onClick={() => setLayout('single')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'single' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em lista"
                    >
                        <LayoutListIcon className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setLayout('grid')}
                        className={`p-1.5 rounded-md transition-colors ${layout === 'grid' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent)]' : 'text-[var(--color-text-secondary)]'}`}
                        aria-label="Visualização em grade"
                    >
                        <LayoutGridIcon className="w-5 h-5" />
                    </button>
                </div>
            </header>

            <div className="flex-grow mt-6 overflow-y-auto pr-2 -mr-2">
                <div className={`grid ${layout === 'grid' ? 'grid-cols-2' : 'grid-cols-1'} sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6`}>
                    {mantras.map((mantra, index) => (
                         <div
                            key={mantra.id}
                            draggable
                            onDragStart={() => handleDragStart(index)}
                            onDragEnter={() => handleDragEnter(index)}
                            onDragEnd={handleDragEnd}
                            onDragOver={(e) => e.preventDefault()}
                        >
                            <MantraCard mantra={mantra} onUpdate={handleUpdate} onDelete={handleDelete} />
                        </div>
                    ))}
                </div>

                {mantras.length === 0 && (
                     <div className="text-center py-10 text-[var(--color-text-secondary)] col-span-full">
                        <p className="font-serif text-lg">"Eu sou capaz de criar a vida que desejo."</p>
                        <p className="mt-4">Clique no botão '+' para adicionar sua primeira afirmação.</p>
                    </div>
                )}
            </div>
             <button
                onClick={() => setIsAddModalOpen(true)}
                className="fixed bottom-8 right-8 w-16 h-16 bg-[var(--color-accent)] text-[var(--color-bg-primary)] rounded-full shadow-lg hover:opacity-90 transition-opacity flex items-center justify-center z-30"
                aria-label="Adicionar Novo Mantra"
            >
                <PlusIcon className="w-8 h-8"/>
            </button>

            {isAddModalOpen && <AddMantraModal onAdd={handleAdd} onClose={() => setIsAddModalOpen(false)} />}
            
            {pendingDelete && (
                <div
                    className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
                    role="dialog"
                    aria-modal="true"
                >
                    <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                            <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                        </div>
                        <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                        <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
                            Tem certeza que deseja excluir este mantra?
                        </p>
                        <div className="mt-6 flex justify-center gap-3">
                            <button
                                onClick={() => setPendingDelete(null)}
                                className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={confirmDelete}
                                className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
                            >
                                Excluir
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}