import React, { useState } from 'react';
import { Category } from '../types';
import { MenuIcon, XIcon, ActivityIcon, SunIcon, MoonIcon, ChartBarIcon, BookOpenIcon, ImageIcon, CalendarIcon, SparklesIcon, SmileIcon, BedIcon, SettingsIcon, TrophyIcon, QuoteIcon, TargetIcon } from './Icons';

interface SidebarProps {
  categories: Category[];
  selectedCategoryId: string;
  setSelectedCategoryId: (id: string) => void;
  currentTheme: string;
  onThemeChange: (theme: string) => void;
  onShowHowToUse: () => void;
  onOpenCategorySettings: () => void;
}

const ThemeSwitcher: React.FC<{ currentTheme: string; onThemeChange: (theme: string) => void }> = ({ currentTheme, onThemeChange }) => {
  return (
    <div className="mt-8 px-2">
      <h2 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider">Tema</h2>
      <div className="mt-4 flex items-center justify-around rounded-lg bg-[var(--color-bg-primary)] p-1">
        <button
          onClick={() => onThemeChange('lightBlue')}
          className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-md text-sm transition-colors ${
            currentTheme === 'lightBlue' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent-text)]' : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)]'
          }`}
          aria-pressed={currentTheme === 'lightBlue'}
        >
          <SunIcon className="h-5 w-5" />
          Claro
        </button>
        <button
          onClick={() => onThemeChange('graphiteOrange')}
          className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-md text-sm transition-colors ${
            currentTheme === 'graphiteOrange' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent-text)]' : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)]'
          }`}
          aria-pressed={currentTheme === 'graphiteOrange'}
        >
          <MoonIcon className="h-5 w-5" />
          Escuro
        </button>
         <button
          onClick={() => onThemeChange('midnightViolet')}
          className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-md text-sm transition-colors ${
            currentTheme === 'midnightViolet' ? 'bg-[var(--color-bg-secondary)] text-[var(--color-accent-text)]' : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-secondary)]'
          }`}
          aria-pressed={currentTheme === 'midnightViolet'}
        >
          <SparklesIcon className="h-5 w-5" />
          Místico
        </button>
      </div>
    </div>
  );
};


export default function Sidebar({ categories, selectedCategoryId, setSelectedCategoryId, currentTheme, onThemeChange, onShowHowToUse, onOpenCategorySettings }: SidebarProps): React.ReactElement {
  const [isOpen, setIsOpen] = useState(false);

  const NavContent = () => (
    <>
      <nav className="mt-8">
        <div className="px-2 mb-4 space-y-1">
           <button
              onClick={() => {
                setSelectedCategoryId('reports');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'reports'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <ChartBarIcon className="h-5 w-5 mr-3" />
              <span>Relatório</span>
            </button>
            <button
              onClick={() => {
                setSelectedCategoryId('vision-board');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'vision-board'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <ImageIcon className="h-5 w-5 mr-3" />
              <span>Quadro de Visão</span>
            </button>
             <button
              onClick={() => {
                setSelectedCategoryId('metas');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'metas'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <TargetIcon className="h-5 w-5 mr-3" />
              <span>Quadro de Metas</span>
            </button>
            <button
              onClick={() => {
                setSelectedCategoryId('conquistas');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'conquistas'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <TrophyIcon className="h-5 w-5 mr-3" />
              <span>Conquistas</span>
            </button>
            <button
              onClick={() => {
                setSelectedCategoryId('mantras');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'mantras'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <QuoteIcon className="h-5 w-5 mr-3" />
              <span>Mantras e Afirmações</span>
            </button>
             <button
              onClick={() => {
                setSelectedCategoryId('mood-tracker');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'mood-tracker'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <SmileIcon className="h-5 w-5 mr-3" />
              <span>Controle de Humor</span>
            </button>
            <button
              onClick={() => {
                setSelectedCategoryId('sleep-tracker');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'sleep-tracker'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <BedIcon className="h-5 w-5 mr-3" />
              <span>Controle de Sono</span>
            </button>
            <button
              onClick={() => {
                setSelectedCategoryId('calendar');
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === 'calendar'
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <CalendarIcon className="h-5 w-5 mr-3" />
              <span>Calendário</span>
            </button>
            <button
              onClick={() => {
                onShowHowToUse();
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]`}
            >
              <BookOpenIcon className="h-5 w-5 mr-3" />
              <span>Como Usar</span>
            </button>
        </div>
        <div className="px-2 flex justify-between items-center">
          <h2 className="text-xs font-semibold text-[var(--color-text-secondary)] uppercase tracking-wider">Setores da Vida</h2>
          <button onClick={onOpenCategorySettings} className="p-1 rounded-md text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)] transition-colors" aria-label="Gerenciar setores">
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
        <div className="mt-4 space-y-1">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => {
                setSelectedCategoryId(category.id);
                setIsOpen(false);
              }}
              className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 text-left ${
                selectedCategoryId === category.id
                  ? 'bg-[var(--color-accent-bg-subtle)] text-[var(--color-accent-text)]'
                  : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)]'
              }`}
            >
              <category.icon className="h-5 w-5 mr-3" />
              <span>{category.name}</span>
            </button>
          ))}
        </div>
      </nav>
      <ThemeSwitcher currentTheme={currentTheme} onThemeChange={onThemeChange} />
    </>
  );


  return (
    <>
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-30">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 rounded-md bg-[var(--color-bg-secondary)] text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)]"
          aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
          aria-expanded={isOpen}
        >
          {isOpen ? <XIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
        </button>
      </div>
      
      {/* Overlay for mobile */}
      {isOpen && <div className="md:hidden fixed inset-0 bg-black/60 z-10" onClick={() => setIsOpen(false)}></div>}

      {/* Sidebar */}
      <aside className={`fixed md:relative top-0 left-0 h-full bg-[var(--color-bg-secondary)] w-64 md:w-72 flex-shrink-0 flex flex-col p-4 transition-transform duration-300 ease-in-out z-20 ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
        <div className="flex items-center space-x-2 px-2 mt-12 md:mt-2">
           <ActivityIcon className="h-8 w-8 text-[var(--color-accent)]"/>
           <h1 className="text-xl font-bold text-[var(--color-text-primary)]">Clareza & Consciencia</h1>
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavContent />
        </div>
        <div className="mt-auto text-center text-xs text-[var(--color-text-secondary)]">
          <p>Seu painel de controle pessoal.</p>
        </div>
      </aside>
    </>
  );
}