import React, { useState, useRef, MouseEvent as ReactMouseEvent, TouchEvent as ReactTouchEvent } from 'react';
import { VisionBoardState, VisionBoardItem } from '../types';
import { PlusIcon, TrashIcon, PencilIcon, CheckIcon, ImageIcon, ResizeIcon } from './Icons';
import useLocalStorage from '../hooks/useLocalStorage';
import HelpTooltip from './HelpTooltip';

interface VisionBoardProps {
  visionBoard: VisionBoardState;
  onUpdate: (newState: VisionBoardState) => void;
}

// Helper para normalizar eventos de mouse e toque
const getClientCoords = (e: ReactMouseEvent | MouseEvent | ReactTouchEvent | TouchEvent) => {
    if ('touches' in e) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
    return { x: e.clientX, y: e.clientY };
};


const BoardItem: React.FC<{
    item: VisionBoardItem;
    isSelected: boolean;
    isEditing: boolean;
    onSelect: (e: ReactMouseEvent | ReactTouchEvent) => void;
    onUpdate: (item: VisionBoardItem) => void;
    onDelete: () => void;
}> = ({ item, isSelected, isEditing, onSelect, onUpdate, onDelete }) => {
    
    const handleInteractionStart = (e: ReactMouseEvent<HTMLDivElement | HTMLButtonElement> | ReactTouchEvent<HTMLDivElement | HTMLButtonElement>, action: 'drag' | 'resize') => {
        if (!isEditing) return;
        
        e.stopPropagation();
        if(action === 'drag') {
            onSelect(e as ReactMouseEvent<HTMLDivElement> | ReactTouchEvent<HTMLDivElement>);
        }

        const startCoords = getClientCoords(e);
        const startItem = { ...item };

        const handleMouseMove = (moveEvent: MouseEvent | TouchEvent) => {
            const moveCoords = getClientCoords(moveEvent);
            const dx = moveCoords.x - startCoords.x;
            const dy = moveCoords.y - startCoords.y;

            if (action === 'drag') {
                onUpdate({ ...item, x: startItem.x + dx, y: startItem.y + dy });
            } else { // resize
                const aspect = startItem.width / startItem.height;
                const newWidth = startItem.width + dx;
                
                if (newWidth > 50) { // minimum size
                    onUpdate({ ...item, width: newWidth, height: newWidth / aspect });
                }
            }
        };

        const handleMouseUp = () => {
            document.removeEventListener('mousemove', handleMouseMove as EventListener);
            document.removeEventListener('mouseup', handleMouseUp);
            document.removeEventListener('touchmove', handleMouseMove as EventListener);
            document.removeEventListener('touchend', handleMouseUp);
        };
        
        document.addEventListener('mousemove', handleMouseMove as EventListener);
        document.addEventListener('mouseup', handleMouseUp);
        document.addEventListener('touchmove', handleMouseMove as EventListener);
        document.addEventListener('touchend', handleMouseUp);
    };

    return (
        <div
            className="absolute select-none"
            style={{
                left: item.x,
                top: item.y,
                width: item.width,
                height: item.height,
                zIndex: item.zIndex,
                transform: `rotate(${item.rotation}deg)`,
                cursor: isEditing ? 'grab' : 'default',
                boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
            }}
            onMouseDown={(e) => handleInteractionStart(e, 'drag')}
            onTouchStart={(e) => handleInteractionStart(e, 'drag')}
        >
            <img src={item.src} alt="Vision board item" className="w-full h-full object-cover pointer-events-none rounded-sm" />
            {isSelected && isEditing && (
                <>
                    <div className="absolute -inset-0.5 border-2 border-dashed border-[var(--color-accent)] rounded-sm pointer-events-none"></div>
                    <button
                        onClick={(e) => { e.stopPropagation(); onDelete(); }}
                        onTouchStart={(e) => { e.stopPropagation(); onDelete(); }}
                        className="absolute -top-3 -left-3 w-7 h-7 bg-red-500 rounded-full flex items-center justify-center text-white cursor-pointer hover:bg-red-600 transition-colors"
                        aria-label="Excluir item"
                    >
                        <TrashIcon className="w-4 h-4" />
                    </button>
                    <button
                        className="absolute -bottom-3 -right-3 w-8 h-8 bg-[var(--color-accent)] rounded-full flex items-center justify-center cursor-se-resize shadow-lg hover:scale-110 transition-transform"
                        onMouseDown={(e) => handleInteractionStart(e, 'resize')}
                        onTouchStart={(e) => handleInteractionStart(e, 'resize')}
                        aria-label="Redimensionar item"
                    >
                        <ResizeIcon className="w-5 h-5 text-[var(--color-bg-primary)]" />
                    </button>
                </>
            )}
        </div>
    );
};

export default function VisionBoard({ visionBoard, onUpdate }: VisionBoardProps): React.ReactElement {
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [boardOffset, setBoardOffset] = useLocalStorage('visionBoardOffset', { x: 0, y: 0 });
    const fileInputRef = useRef<HTMLInputElement>(null);
    const boardRef = useRef<HTMLDivElement>(null);
    const isPanning = useRef(false);

    const handleAddItem = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (loadEvent) => {
                const img = new Image();
                img.onload = () => {
                    const boardBounds = boardRef.current?.getBoundingClientRect();
                    const viewWidth = boardBounds?.width || 800;
                    const viewHeight = boardBounds?.height || 600;

                    const MAX_WIDTH = 250;
                    const aspect = img.width / img.height;
                    const width = Math.min(img.width, MAX_WIDTH);
                    const height = width / aspect;

                    const newItem: VisionBoardItem = {
                        id: `item-${Date.now()}`,
                        src: loadEvent.target?.result as string,
                        x: (viewWidth / 2) - (width / 2) - boardOffset.x,
                        y: (viewHeight / 2) - (height / 2) - boardOffset.y,
                        width,
                        height,
                        rotation: 0,
                        zIndex: (Math.max(0, ...visionBoard.map(i => i.zIndex)) || 0) + 1,
                    };
                    onUpdate([...visionBoard, newItem]);
                }
                img.src = loadEvent.target?.result as string;
            };
            reader.readAsDataURL(file);
            e.target.value = '';
        }
    };
    
    const handleUpdateItem = (updatedItem: VisionBoardItem) => {
        onUpdate(visionBoard.map(item => item.id === updatedItem.id ? updatedItem : item));
    };

    const handleDeleteItem = (id: string) => {
        onUpdate(visionBoard.filter(item => item.id !== id));
        setSelectedId(null);
    };

    const handleSelect = (id: string) => {
        setSelectedId(id);
        const maxZ = Math.max(0, ...visionBoard.map(i => i.zIndex));
        onUpdate(visionBoard.map(item => item.id === id ? { ...item, zIndex: maxZ + 1 } : item));
    };
    
    const handlePanStart = (e: ReactMouseEvent<HTMLDivElement> | ReactTouchEvent<HTMLDivElement>) => {
        if(isEditing) return;
        
        e.preventDefault();
        isPanning.current = true;
        
        const startCoords = getClientCoords(e);
        const startOffset = { ...boardOffset };

        const handlePanMove = (moveEvent: MouseEvent | TouchEvent) => {
            const moveCoords = getClientCoords(moveEvent);
            const dx = moveCoords.x - startCoords.x;
            const dy = moveCoords.y - startCoords.y;
            setBoardOffset({x: startOffset.x + dx, y: startOffset.y + dy});
        };

        const handlePanEnd = () => {
            isPanning.current = false;
            document.removeEventListener('mousemove', handlePanMove as EventListener);
            document.removeEventListener('mouseup', handlePanEnd);
            document.removeEventListener('touchmove', handlePanMove as EventListener);
            document.removeEventListener('touchend', handlePanEnd);
        };
        
        document.addEventListener('mousemove', handlePanMove as EventListener);
        document.addEventListener('mouseup', handlePanEnd);
        document.addEventListener('touchmove', handlePanMove as EventListener);
        document.addEventListener('touchend', handlePanEnd);
    }
    
    const handleBoardClick = () => {
        if(isEditing && !isPanning.current) {
            setSelectedId(null);
        }
    }

    return (
        <div className="h-full flex flex-col pt-16 md:pt-0">
            <header className="flex-shrink-0 flex justify-between items-center">
                <div>
                    <div className="flex items-center gap-3">
                        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Quadro de Visão</h2>
                         <HelpTooltip
                          title="Exemplos de Uso"
                          examples={[
                            "Adicione imagens que representam seus sonhos: a casa que deseja, um destino de viagem, um carro.",
                            "Crie uma colagem com fotos de pessoas que te inspiram ou de momentos felizes que deseja repetir."
                          ]}
                        />
                    </div>
                    <p className="mt-1 text-[var(--color-text-secondary)]">Crie uma colagem livre com suas inspirações.</p>
                </div>
                <div className="flex items-center gap-2">
                    {isEditing && (
                         <button
                            onClick={() => fileInputRef.current?.click()}
                            className="inline-flex items-center gap-2 px-3 py-2 border border-transparent text-sm font-semibold rounded-md shadow-sm text-[var(--color-bg-primary)] bg-[var(--color-accent)] hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--color-accent)]"
                            aria-label="Adicionar nova imagem"
                         >
                            <PlusIcon className="w-5 h-5" />
                            <span className="hidden sm:inline">Adicionar Visão</span>
                         </button>
                    )}
                    <button
                        onClick={() => setIsEditing(!isEditing)}
                        className="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)]"
                    >
                        {isEditing ? <CheckIcon className="w-5 h-5"/> : <PencilIcon className="w-5 h-5" />}
                        <span className="hidden sm:inline">{isEditing ? 'Concluir Edição' : 'Editar Quadro'}</span>
                    </button>
                </div>
            </header>
            
            <div className="flex-grow mt-6 relative">
                 <div 
                    ref={boardRef}
                    className="absolute inset-0 bg-[var(--color-bg-secondary)] rounded-2xl shadow-inner overflow-hidden"
                    style={{ cursor: isEditing ? 'default' : 'grab' }}
                    onMouseDown={handlePanStart}
                    onTouchStart={handlePanStart}
                    onClick={handleBoardClick}
                 >
                    <div
                      className="absolute top-0 left-0"
                      style={{transform: `translate(${boardOffset.x}px, ${boardOffset.y}px)`}}
                    >
                        {visionBoard.map(item => (
                            <BoardItem
                                key={item.id}
                                item={item}
                                isSelected={selectedId === item.id}
                                isEditing={isEditing}
                                onSelect={(e) => { e.stopPropagation(); handleSelect(item.id); }}
                                onUpdate={handleUpdateItem}
                                onDelete={() => handleDeleteItem(item.id)}
                            />
                        ))}
                    </div>

                    {visionBoard.length === 0 && (
                       <div className="w-full h-full flex flex-col items-center justify-center text-center p-4 border-2 border-dashed border-[var(--color-border)] rounded-2xl pointer-events-none">
                          <ImageIcon className="mx-auto h-12 w-12 text-[var(--color-text-secondary)]" />
                          <h3 className="mt-4 text-lg font-medium text-[var(--color-text-primary)]">Seu Mood Board está Vazio</h3>
                          <p className="mt-1 text-sm text-[var(--color-text-secondary)]">Clique em 'Editar' para começar a adicionar imagens.</p>
                        </div>
                    )}
                 </div>

                 <input type="file" ref={fileInputRef} onChange={handleAddItem} className="hidden" accept="image/*" />
            </div>
        </div>
    );
}
