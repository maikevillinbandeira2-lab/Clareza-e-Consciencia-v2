import React, { useState, useMemo, useEffect } from 'react';
import { SleepState, SleepType, SleepEntry, DreamQualityLevel, DreamEntry } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, TrashIcon, ZzzIcon, MoonPauseIcon, EyeOffIcon, AlertTriangleIcon, CloudIcon, CloudOffIcon, StormIcon, FaceFrownIcon, FaceNeutralIcon, SparklesIcon, FaceSmileIcon, PencilIcon, CheckIcon, XIcon } from './Icons';

interface SleepTrackerProps {
  sleepState: SleepState;
  onUpdate: (newState: SleepState) => void;
}

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const sleepOptions: { [key in SleepType]: { label: string; Icon: React.ElementType; description: string; colorClass: string; ringColorClass: string; bgColorClass: string; } } = {
    'uninterrupted': { 
        label: 'Sono Inteiro', 
        Icon: ZzzIcon, 
        description: 'Dormiu profundamente, sem interrupções.',
        colorClass: 'text-blue-500', 
        ringColorClass: 'ring-blue-500',
        bgColorClass: 'bg-blue-500/80',
    },
    'interrupted': { 
        label: 'Com Pausa', 
        Icon: MoonPauseIcon, 
        description: 'Acordou, mas voltou a dormir com facilidade.',
        colorClass: 'text-indigo-500',
        ringColorClass: 'ring-indigo-500',
        bgColorClass: 'bg-indigo-500/80',
    },
    'difficult': { 
        label: 'Dificuldade', 
        Icon: AlertTriangleIcon, 
        description: 'Sono agitado ou demorou para adormecer.',
        colorClass: 'text-amber-500',
        ringColorClass: 'ring-amber-500',
        bgColorClass: 'bg-amber-500/80',
    },
    'sleepless': { 
        label: 'Noite em Claro', 
        Icon: EyeOffIcon, 
        description: 'Não conseguiu dormir ou dormiu muito pouco.',
        colorClass: 'text-slate-500',
        ringColorClass: 'ring-slate-500',
        bgColorClass: 'bg-slate-500/80',
    },
};

const dreamOptions: { [key: string]: { label: string; Icon: React.ElementType; description: string; colorClass: string; } } = {
    '5': { label: 'Bom', Icon: FaceSmileIcon, description: 'Sonhos agradáveis, felizes e com sensação positiva.', colorClass: 'text-lime-500' },
    '4': { label: 'Intuitivo', Icon: SparklesIcon, description: 'Sonhos que parecem trazer uma mensagem, insight ou clareza.', colorClass: 'text-cyan-500' },
    '3': { label: 'Neutro', Icon: FaceNeutralIcon, description: 'Sonhos comuns, sem um significado ou emoção marcante.', colorClass: 'text-yellow-500' },
    '2': { label: 'Incômodo', Icon: FaceFrownIcon, description: 'Sonhos que trazem desconforto ou te deixam inquieto.', colorClass: 'text-orange-500' },
    '1': { label: 'Pesadelo', Icon: StormIcon, description: 'Sonhos perturbadores que causam medo ou angústia.', colorClass: 'text-red-500' },
};

export default function SleepTracker({ sleepState, onUpdate }: SleepTrackerProps): React.ReactElement {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<Date>(new Date());
  
  const selectedDayKey = formatDateKey(selectedDay);
  const currentDaySleep = sleepState[selectedDayKey];
  
  const [localSleepEntry, setLocalSleepEntry] = useState<SleepEntry | undefined>(currentDaySleep);
  const [isEditing, setIsEditing] = useState<boolean>(!currentDaySleep);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    const entry = sleepState[formatDateKey(selectedDay)];
    setLocalSleepEntry(entry);
    setIsEditing(!entry); // Enter edit mode if no entry exists
  }, [selectedDay, sleepState]);

  const monthGrid = useMemo(() => {
    const date = new Date(currentDate);
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(startDate.getDate() - startDate.getDay());

    const days = [];
    for (let i = 0; i < 42; i++) {
      days.push(new Date(startDate));
      startDate.setDate(startDate.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  const handlePrevMonth = () => setCurrentDate(prev => { const d = new Date(prev); d.setMonth(d.getMonth() - 1); return d; });
  const handleNextMonth = () => setCurrentDate(prev => { const d = new Date(prev); d.setMonth(d.getMonth() + 1); return d; });

  const updateEntry = (dayKey: string, newEntry: SleepEntry | undefined) => {
    const newState = { ...sleepState };
    if (newEntry && newEntry.type) { // Ensure there is at least a type
        newState[dayKey] = newEntry;
    } else {
        delete newState[dayKey];
    }
    onUpdate(newState);
  };

  const handleSelectSleepType = (type: SleepType) => {
    setLocalSleepEntry(prev => ({
        ...(prev || { type }),
        type: type,
    }));
  };

  const handleUpdateDream = (dreamData: Partial<DreamEntry>) => {
      if(!localSleepEntry) return;
      const newDreamData: DreamEntry = {
          ...(localSleepEntry.dream || { hadDream: false }),
          ...dreamData
      };
      
      if (!newDreamData.hadDream) {
          delete newDreamData.dreamQuality;
      }
      
      setLocalSleepEntry(prev => ({
          ...prev!,
          dream: newDreamData,
      }));
  };

  const handleSave = () => {
    if (localSleepEntry) {
        updateEntry(selectedDayKey, localSleepEntry);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setLocalSleepEntry(currentDaySleep);
    setIsEditing(false);
  };
  
  const confirmDelete = () => {
    updateEntry(selectedDayKey, undefined);
    setShowDeleteConfirm(false);
  };
  
  return (
    <div className="h-full flex flex-col pt-16 md:pt-0">
      <header>
        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Controle de Sono</h2>
        <p className="mt-1 text-[var(--color-text-secondary)]">Avalie a qualidade do seu descanso para otimizar sua recuperação.</p>
      </header>

      <div className="flex-grow mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[var(--color-bg-secondary)] p-4 sm:p-6 rounded-xl shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronLeftIcon className="w-5 h-5"/></button>
                <h3 className="text-lg font-semibold text-center capitalize">{currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h3>
                <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronRightIcon className="w-5 h-5"/></button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center">
                 {WEEKDAYS.map(day => <div key={day} className="text-xs font-bold text-[var(--color-text-secondary)] py-2">{day}</div>)}
                 {monthGrid.map((day, i) => {
                     const key = formatDateKey(day);
                     const sleepEntry = sleepState[key];
                     const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                     const isSelected = key === selectedDayKey;
                     const isToday = key === formatDateKey(new Date());

                     return (
                         <div key={i} onClick={() => setSelectedDay(day)} className={`h-12 sm:h-16 rounded-lg cursor-pointer flex items-center justify-center transition-all duration-200 border-2 ${isSelected ? 'border-[var(--color-accent)]' : 'border-transparent'}`}>
                             <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex flex-col items-center justify-center transition-colors relative ${sleepEntry ? sleepOptions[sleepEntry.type].bgColorClass : 'bg-[var(--color-bg-tertiary)]'}`}>
                                <span className={`font-semibold ${sleepEntry ? 'text-white' : isCurrentMonth ? 'text-[var(--color-text-primary)]' : 'text-gray-500'} ${isToday ? 'relative' : ''}`}>
                                    {day.getDate()}
                                    {isToday && <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-[var(--color-accent)] rounded-full"></div>}
                                </span>
                                {sleepEntry?.dream?.hadDream && (() => {
                                    const dreamQuality = sleepEntry.dream.dreamQuality;
                                    const colorClass = dreamQuality ? dreamOptions[dreamQuality].colorClass : 'text-cyan-300';
                                    return <CloudIcon 
                                        className={`absolute top-1 right-1 w-3.5 h-3.5 ${colorClass}`}
                                        style={{ filter: 'drop-shadow(0 0 2px rgba(0,0,0,0.8))' }} 
                                        title={dreamQuality ? `Sonho: ${dreamOptions[dreamQuality].label}` : 'Sonho registrado'}
                                    />;
                                })()}
                             </div>
                         </div>
                     );
                 })}
            </div>
        </div>

        <div className="lg:col-span-1 bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg flex flex-col">
            <h3 className="text-xl font-bold text-center text-[var(--color-text-primary)] flex-shrink-0">
                {selectedDay.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' })}
            </h3>
            <div className="flex-grow my-4 flex flex-col space-y-4 overflow-y-auto pr-2 -mr-4 min-h-0">
              {!isEditing && currentDaySleep ? (
                // VIEW MODE
                (() => {
                  const sleepMeta = sleepOptions[currentDaySleep.type];
                  const SleepIcon = sleepMeta.Icon;

                  const dreamQuality = currentDaySleep.dream?.dreamQuality;
                  const dreamMeta = dreamQuality ? dreamOptions[dreamQuality] : null;
                  const DreamIcon = dreamMeta?.Icon;
                  
                  return (
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-semibold text-center text-[var(--color-text-secondary)] mb-3">Qualidade do Sono</p>
                        <div className="p-4 rounded-lg flex flex-col items-center text-center bg-[var(--color-bg-tertiary)]">
                          <SleepIcon className={`w-10 h-10 mb-2 ${sleepMeta.colorClass}`} />
                          <h4 className="font-bold text-lg text-[var(--color-text-primary)]">{sleepMeta.label}</h4>
                          <p className="text-xs text-[var(--color-text-secondary)] mt-1">{sleepMeta.description}</p>
                        </div>
                      </div>
                      {currentDaySleep.dream && (
                        <div className="pt-4 border-t border-[var(--color-border)]">
                          <p className="text-sm font-semibold text-center text-[var(--color-text-secondary)] mb-3">Registro de Sonhos</p>
                          {currentDaySleep.dream.hadDream ? (
                            DreamIcon && dreamMeta ? (
                              <div className="p-4 rounded-lg flex flex-col items-center text-center bg-[var(--color-bg-tertiary)]">
                                <DreamIcon className={`w-10 h-10 mb-2 ${dreamMeta.colorClass}`} />
                                <h4 className="font-bold text-lg text-[var(--color-text-primary)]">{dreamMeta.label}</h4>
                                <p className="text-xs text-[var(--color-text-secondary)] mt-1">{dreamMeta.description}</p>
                              </div>
                            ) : (
                              <div className="p-4 rounded-lg flex items-center justify-center gap-3 bg-[var(--color-bg-tertiary)]">
                                <CloudIcon className="w-8 h-8 text-cyan-400" />
                                <p className="font-semibold">Sonho registrado (sem detalhes)</p>
                              </div>
                            )
                          ) : (
                            <div className="p-4 rounded-lg flex items-center justify-center gap-3 bg-[var(--color-bg-tertiary)]">
                              <CloudOffIcon className="w-8 h-8 text-red-500" />
                              <p className="font-semibold">Sem registro de sonho</p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                // EDIT MODE
                <>
                  <div>
                    <p className="text-sm font-semibold text-center text-[var(--color-text-secondary)] mb-3">Como foi sua noite de sono?</p>
                    <div className="grid grid-cols-2 gap-2">
                      {(Object.keys(sleepOptions) as SleepType[]).map(type => {
                        const { label, Icon, colorClass } = sleepOptions[type];
                        const isSelected = localSleepEntry?.type === type;
                        return (
                          <button
                            key={type}
                            onClick={() => handleSelectSleepType(type)}
                            className={`p-3 rounded-lg text-center border-2 transition-all duration-200 flex flex-col items-center justify-center h-24 ${isSelected ? `bg-[var(--color-bg-tertiary)] ${sleepOptions[type].ringColorClass.replace('ring-','border-')}` : 'border-transparent bg-[var(--color-bg-tertiary)] hover:border-[var(--color-border)]'}`}
                          >
                            <Icon className={`w-7 h-7 mb-1 ${colorClass}`} />
                            <h4 className={`text-xs font-bold ${isSelected ? 'text-[var(--color-text-primary)]' : 'text-[var(--color-text-tertiary)]'}`}>{label}</h4>
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {localSleepEntry && (
                      <div className="pt-4 border-t border-[var(--color-border)]">
                          <p className="text-sm font-semibold text-center text-[var(--color-text-secondary)] mb-3">Registro de Sonhos</p>
                          <div className="flex gap-2">
                              <button onClick={() => handleUpdateDream({ hadDream: true })} className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${localSleepEntry.dream?.hadDream ? 'border-green-500 bg-[var(--color-bg-tertiary)]' : 'border-transparent bg-[var(--color-bg-tertiary)] hover:border-[var(--color-border)]'}`}>
                                  <CloudIcon className="w-5 h-5 text-green-500" />
                                  <span className="text-sm font-semibold">Com Sonho</span>
                              </button>
                              <button onClick={() => handleUpdateDream({ hadDream: false })} className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${localSleepEntry.dream?.hadDream === false ? 'border-red-500 bg-[var(--color-bg-tertiary)]' : 'border-transparent bg-[var(--color-bg-tertiary)] hover:border-[var(--color-border)]'}`}>
                                  <CloudOffIcon className="w-5 h-5 text-red-500"/>
                                  <span className="text-sm font-semibold">Sem Sonho</span>
                              </button>
                          </div>
                          
                          {localSleepEntry.dream?.hadDream && (
                              <div className="mt-3">
                                  <p className="text-xs text-center text-[var(--color-text-secondary)] mb-2">Qual foi a sensação predominante do sonho?</p>
                                  <div className="flex justify-around bg-[var(--color-bg-tertiary)] p-1 rounded-lg">
                                      {Object.entries(dreamOptions).reverse().map(([level, { Icon, colorClass, label }]) => (
                                          <button 
                                              key={level} 
                                              onClick={() => handleUpdateDream({ dreamQuality: Number(level) as DreamQualityLevel })}
                                              className={`p-2 rounded-md transition-colors ${localSleepEntry.dream?.dreamQuality === Number(level) ? 'bg-[var(--color-bg-primary)]' : 'hover:bg-[var(--color-bg-primary)]'}`}
                                              title={label}
                                          >
                                              <Icon className={`w-6 h-6 ${colorClass}`} />
                                          </button>
                                      ))}
                                  </div>
                              </div>
                          )}
                      </div>
                  )}
                </>
              )}
            </div>
             
            <div className="mt-auto flex-shrink-0 space-y-2">
              {isEditing ? (
                  <div className="flex gap-2">
                      <button onClick={handleCancel} className="flex-1 flex items-center justify-center gap-2 text-sm font-medium py-2 px-4 rounded-md bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors">
                          <XIcon className="w-4 h-4"/> Cancelar
                      </button>
                      <button onClick={handleSave} disabled={!localSleepEntry} className="flex-1 flex items-center justify-center gap-2 text-sm font-semibold py-2 px-4 rounded-md text-[var(--color-bg-primary)] bg-[var(--color-accent)] hover:opacity-90 disabled:opacity-50 transition-opacity">
                          <CheckIcon className="w-4 h-4"/> Salvar
                      </button>
                  </div>
              ) : (
                  <div className="flex gap-2">
                      {currentDaySleep && 
                        <button onClick={() => setShowDeleteConfirm(true)} className="flex-1 flex items-center justify-center gap-2 text-sm font-medium py-2 px-4 rounded-md text-red-500 hover:bg-red-500/10 transition-colors">
                            <TrashIcon className="w-4 h-4" /> Excluir
                        </button>
                      }
                      <button onClick={() => setIsEditing(true)} className="flex-1 flex items-center justify-center gap-2 text-sm font-semibold py-2 px-4 rounded-md text-[var(--color-accent-text)] bg-[var(--color-accent-bg-subtle)] hover:bg-[var(--color-accent-bg-subtle)]/80 transition-colors">
                          <PencilIcon className="w-4 h-4" /> Editar
                      </button>
                  </div>
              )}
            </div>
        </div>
      </div>
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
            <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                    <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                <p className="mt-2 text-sm text-[var(--color-text-secondary)]">Tem certeza que deseja remover o registro de sono para este dia?</p>
                <div className="mt-6 flex justify-center gap-3">
                    <button onClick={() => setShowDeleteConfirm(false)} className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors">Cancelar</button>
                    <button onClick={confirmDelete} className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors">Excluir</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}