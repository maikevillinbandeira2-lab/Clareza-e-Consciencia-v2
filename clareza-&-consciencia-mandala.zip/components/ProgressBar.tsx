import React from 'react';

interface ProgressBarProps {
  progress: number;
  small?: boolean;
}

export default function ProgressBar({ progress, small = false }: ProgressBarProps): React.ReactElement {
  const validProgress = Math.max(0, Math.min(100, progress));

  return (
    <div className={`w-full bg-[var(--color-bg-tertiary)] rounded-full ${small ? 'h-1.5' : 'h-2.5'}`}>
      <div
        className="bg-[var(--color-accent)] rounded-full transition-all duration-500 ease-out"
        style={{ width: `${validProgress}%`, height: '100%' }}
      ></div>
    </div>
  );
}