import React from 'react';
import { QuestionMarkCircleIcon } from './Icons';

interface HelpTooltipProps {
  title: string;
  examples: string[];
}

const HelpTooltip: React.FC<HelpTooltipProps> = ({ title, examples }) => {
  return (
    <div className="relative group flex items-center">
      <QuestionMarkCircleIcon className="w-6 h-6 text-[var(--color-text-secondary)] cursor-help" />
      <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-72 p-4 bg-[var(--color-bg-primary)] text-sm text-[var(--color-text-tertiary)] rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity duration-300 pointer-events-none z-10">
        <h4 className="font-bold text-[var(--color-text-primary)] mb-2">{title}</h4>
        <ul className="list-disc list-inside space-y-2">
          {examples.map((example, index) => (
            <li key={index}>{example}</li>
          ))}
        </ul>
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-b-4 border-b-[var(--color-bg-primary)]"></div>
      </div>
    </div>
  );
};

export default HelpTooltip;