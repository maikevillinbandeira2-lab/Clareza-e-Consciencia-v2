import React, { useState, useMemo } from 'react';
import { CalendarState, CalendarEventItem } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, ImageIcon, LinkIcon, MusicIcon, PlusIcon, TrashIcon, FileTextIcon, MoonStarIcon, AlertTriangleIcon } from './Icons';
import CalendarEventModal from './CalendarEventModal';
import useLocalStorage from '../hooks/useLocalStorage';
import { getMoonPhase, getSkyOfTheWeek } from '../utils/moon';

interface CalendarProps {
  calendarEvents: CalendarState;
  onUpdate: (newState: CalendarState) => void;
}

type ViewMode = 'month' | 'week' | 'day';

const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export default function Calendar({ calendarEvents, onUpdate }: CalendarProps): React.ReactElement {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<ViewMode>('month');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isMysticalViewEnabled, setIsMysticalViewEnabled] = useLocalStorage('mysticalView', false);
  const [pendingDeleteItem, setPendingDeleteItem] = useState<CalendarEventItem | null>(null);


  const monthGrid = useMemo(() => {
    const date = new Date(currentDate);
    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    const days = [];
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(startDate.getDate() - startDate.getDay());

    for (let i = 0; i < 42; i++) {
      days.push(new Date(startDate));
      startDate.setDate(startDate.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  const weekGrid = useMemo(() => {
    const date = new Date(currentDate);
    const dayOfWeek = date.getDay();
    const startDate = new Date(date);
    startDate.setDate(date.getDate() - dayOfWeek);
    
    const weekDays = [];
    for(let i=0; i<7; i++){
        weekDays.push(new Date(startDate));
        startDate.setDate(startDate.getDate() + 1);
    }
    return weekDays;
  }, [currentDate]);

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setIsModalOpen(true);
  };
  
  const handleViewDateClick = (date: Date) => {
    setCurrentDate(date);
    setViewMode('day');
  };

  const handlePrev = () => {
    const newDate = new Date(currentDate);
    if (viewMode === 'month') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else if (viewMode === 'week') {
      newDate.setDate(newDate.getDate() - 7);
    } else {
       newDate.setDate(newDate.getDate() - 1);
    }
    setCurrentDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(currentDate);
    if (viewMode === 'month') {
      newDate.setMonth(newDate.getMonth() + 1);
    } else if (viewMode === 'week') {
      newDate.setDate(newDate.getDate() + 7);
    } else {
       newDate.setDate(newDate.getDate() + 1);
    }
    setCurrentDate(newDate);
  };

  const handleSaveEvents = (date: Date, events: CalendarEventItem[]) => {
    const key = formatDateKey(date);
    onUpdate({
      ...calendarEvents,
      [key]: events,
    });
  };

  const confirmDeleteItem = () => {
      if(pendingDeleteItem) {
          const updatedEvents = (calendarEvents[formatDateKey(currentDate)] || []).filter(e => e.id !== pendingDeleteItem.id);
          handleSaveEvents(currentDate, updatedEvents);
          setPendingDeleteItem(null);
      }
  };
  
  const headerTitle = useMemo(() => {
    if (viewMode === 'month') {
        return currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
    }
    if(viewMode === 'week') {
        const start = weekGrid[0];
        const end = weekGrid[6];
        return `${start.toLocaleDateString('pt-BR', {day: '2-digit', month: 'short'})} - ${end.toLocaleDateString('pt-BR', {day: '2-digit', month: 'short', year: 'numeric'})}`;
    }
    return currentDate.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric'});
  }, [currentDate, viewMode, weekGrid]);


  const renderEventIcons = (date: Date) => {
    const key = formatDateKey(date);
    const events = calendarEvents[key];
    if (!events || events.length === 0) return null;

    const icons = new Set(events.map(e => e.type));
    
    return (
      <div className="absolute bottom-1 right-1 flex gap-1">
        {icons.has('image') && <ImageIcon className="w-2.5 h-2.5 text-[var(--color-text-secondary)]" />}
        {icons.has('link') && <LinkIcon className="w-2.5 h-2.5 text-[var(--color-text-secondary)]" />}
        {icons.has('audio') && <MusicIcon className="w-2.5 h-2.5 text-[var(--color-text-secondary)]" />}
        {icons.has('note') && <FileTextIcon className="w-2.5 h-2.5 text-[var(--color-text-secondary)]" />}
      </div>
    );
  };
  
  const EventItemDisplay: React.FC<{item: CalendarEventItem; onDelete: () => void}> = ({ item, onDelete }) => {
    return (
      <div className="relative group bg-[var(--color-bg-tertiary)] p-3 rounded-lg flex items-start gap-4">
        {item.type === 'image' && <ImageIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'link' && <LinkIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'audio' && <MusicIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}
        {item.type === 'note' && <FileTextIcon className="w-6 h-6 text-[var(--color-accent-text)] flex-shrink-0 mt-1" />}


        <div className="flex-grow overflow-hidden">
          {item.type === 'image' && <img src={item.content} className="max-h-40 rounded" alt="Item do calendário" />}
          {item.type === 'link' && <a href={item.content} target="_blank" rel="noopener noreferrer" className="text-[var(--color-accent-text-faded)] hover:underline truncate block">{item.title || item.content}</a>}
          {item.type === 'audio' && (
              <div>
                  <p className="text-sm text-[var(--color-text-primary)] truncate">{item.title}</p>
                  <audio controls src={item.content} className="w-full h-8 mt-1"></audio>
              </div>
          )}
          {item.type === 'note' && (
              <div>
                  <p className="text-sm font-semibold text-[var(--color-text-primary)]">{item.title || 'Anotação'}</p>
                  <p className="text-sm text-[var(--color-text-secondary)] mt-1 whitespace-pre-wrap">{item.content}</p>
              </div>
          )}
        </div>
        <button onClick={onDelete} className="absolute top-2 right-2 p-1.5 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 hover:bg-red-500 transition-all duration-300">
            <TrashIcon className="w-4 h-4"/>
        </button>
      </div>
    );
  };
  
  const currentMoonPhase = getMoonPhase(currentDate);

  return (
    <div className="space-y-8 ml-0 pt-16 md:pt-0">
      <header>
        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Calendário</h2>
        <p className="mt-1 text-[var(--color-text-secondary)]">Organize seus dias, anexe inspirações e planeje seu sucesso.</p>
      </header>

      <div className="bg-[var(--color-bg-secondary)] p-4 rounded-xl shadow-lg">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <button onClick={handlePrev} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronLeftIcon className="w-5 h-5"/></button>
            <h3 className="text-lg font-semibold w-64 text-center capitalize">{headerTitle}</h3>
            <button onClick={handleNext} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronRightIcon className="w-5 h-5"/></button>
          </div>
          <div className="flex items-center gap-2 mt-4 sm:mt-0">
            <button
                onClick={() => setIsMysticalViewEnabled(!isMysticalViewEnabled)}
                className={`p-2 rounded-full transition-colors ${isMysticalViewEnabled ? 'text-[var(--color-accent-text)] bg-[var(--color-accent-bg-subtle)]' : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)]'}`}
                title="Ativar/Desativar Modo Intuitivo"
            >
                <MoonStarIcon className="w-5 h-5" />
            </button>
            <div className="flex p-1 rounded-lg bg-[var(--color-bg-tertiary)] space-x-1">
                {(['month', 'week', 'day'] as ViewMode[]).map(mode => (
                <button
                    key={mode}
                    onClick={() => setViewMode(mode)}
                    className={`px-3 py-1.5 text-sm font-semibold rounded-md transition-colors ${
                    viewMode === mode
                        ? 'bg-[var(--color-accent)] text-[var(--color-bg-primary)] font-bold'
                        : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-primary)]'
                    }`}
                >
                    {mode === 'month' ? 'Mês' : mode === 'week' ? 'Semana' : 'Dia'}
                </button>
                ))}
            </div>
          </div>
        </div>

        {/* Calendar Grid */}
        {viewMode === 'month' && (
          <div className="grid grid-cols-7 gap-1">
            {WEEKDAYS.map(day => <div key={day} className="text-center text-xs font-bold text-[var(--color-text-secondary)] py-2">{day}</div>)}
            {monthGrid.map((day, i) => {
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const isToday = formatDateKey(day) === formatDateKey(new Date());
              const phase = isMysticalViewEnabled ? getMoonPhase(day) : null;
              return (
                <div key={i} onClick={() => handleDateClick(day)} className={`relative h-24 rounded-lg p-2 border border-transparent hover:border-[var(--color-accent)] cursor-pointer transition-colors ${isCurrentMonth ? 'bg-[var(--color-bg-tertiary)]' : 'bg-[var(--color-bg-primary)] text-[var(--color-text-secondary)]'}`}>
                  <span className={`text-sm ${isToday ? 'font-bold text-[var(--color-accent-text)]' : ''}`}>{day.getDate()}</span>
                  {phase && <phase.icon title={phase.name} className="absolute top-1.5 right-1.5 w-4 h-4 opacity-70" />}
                  {renderEventIcons(day)}
                </div>
              );
            })}
          </div>
        )}
        
        {viewMode === 'week' && (
           <>
            {isMysticalViewEnabled && (
                <div className="bg-[var(--color-accent-bg-subtle)] border border-[var(--color-accent)]/30 text-[var(--color-accent-text-faded)] rounded-lg p-4 mb-4 text-center">
                    <h4 className="font-bold text-sm mb-1 text-[var(--color-accent-text)]">O Céu da Semana</h4>
                    <p className="text-xs">{getSkyOfTheWeek(currentDate)}</p>
                </div>
            )}
           <div className="grid grid-cols-7 gap-2">
            {weekGrid.map((day, i) => {
                const isToday = formatDateKey(day) === formatDateKey(new Date());
                const phase = isMysticalViewEnabled ? getMoonPhase(day) : null;
                return (
                    <div key={i} className="bg-[var(--color-bg-tertiary)] rounded-lg p-2 space-y-2">
                       <div onClick={() => handleViewDateClick(day)} className="flex items-start justify-between cursor-pointer">
                            <div className="text-left">
                                <span className="text-sm font-semibold text-[var(--color-text-secondary)]">{WEEKDAYS[day.getDay()]}</span>
                                {phase && <span className="text-xs text-[var(--color-text-secondary)] block">{phase.name}</span>}
                            </div>
                            <span className={`text-lg font-bold ${isToday ? 'text-[var(--color-accent-text)]' : ''}`}>{day.getDate()}</span>
                       </div>
                       <div className="space-y-1 h-48 overflow-y-auto">
                          {(calendarEvents[formatDateKey(day)] || []).map(item => (
                              <div key={item.id} className="p-1.5 rounded bg-[var(--color-bg-primary)] flex items-center gap-2">
                                {item.type === 'image' && <ImageIcon className="w-3 h-3 text-[var(--color-text-secondary)]" />}
                                {item.type === 'link' && <LinkIcon className="w-3 h-3 text-[var(--color-text-secondary)]" />}
                                {item.type === 'audio' && <MusicIcon className="w-3 h-3 text-[var(--color-text-secondary)]" />}
                                {item.type === 'note' && <FileTextIcon className="w-3 h-3 text-[var(--color-text-secondary)]" />}
                                <span className="text-xs truncate">{item.title || (item.type === 'image' ? 'Imagem' : 'Item')}</span>
                              </div>
                          ))}
                       </div>
                       <button onClick={() => handleDateClick(day)} className="w-full mt-2 flex items-center justify-center gap-1 text-xs py-1 px-2 rounded-md text-[var(--color-accent-text)] hover:bg-[var(--color-accent-bg-subtle)] transition-colors">
                           <PlusIcon className="w-3 h-3"/> Adicionar
                       </button>
                    </div>
                )
            })}
           </div>
           </>
        )}
        
        {viewMode === 'day' && (
            <div>
              {isMysticalViewEnabled && (
                  <div className="flex items-center justify-center gap-2 text-center mb-4 p-2 bg-[var(--color-bg-tertiary)] rounded-lg">
                      <currentMoonPhase.icon className="w-5 h-5 text-[var(--color-accent-text)]" />
                      <span className="font-semibold text-[var(--color-text-primary)]">{currentMoonPhase.name}</span>
                  </div>
              )}
              <div className="bg-[var(--color-bg-tertiary)] p-4 rounded-lg min-h-[50vh]">
                 <div className="space-y-3">
                  {(calendarEvents[formatDateKey(currentDate)] || []).map(item => (
                      <EventItemDisplay 
                        key={item.id} 
                        item={item} 
                        onDelete={() => setPendingDeleteItem(item)}
                      />
                  ))}

                  {(calendarEvents[formatDateKey(currentDate)] || []).length === 0 && (
                      <div className="text-center py-12 text-[var(--color-text-secondary)]">
                          <p>Nenhum item para este dia.</p>
                          <p className="text-sm">Clique abaixo para adicionar algo.</p>
                      </div>
                  )}
                 </div>
                 <button onClick={() => handleDateClick(currentDate)} className="w-full mt-4 flex items-center justify-center gap-2 text-sm font-medium py-2 px-4 rounded-md text-[var(--color-accent-text)] border-2 border-dashed border-[var(--color-border)] hover:bg-[var(--color-accent-bg-subtle)] hover:border-[var(--color-accent)] transition-colors">
                    <PlusIcon className="w-5 h-5" />
                    Adicionar Item
                </button>
              </div>
            </div>
        )}

      </div>
       {isModalOpen && selectedDate && (
        <CalendarEventModal
          date={selectedDate}
          events={calendarEvents[formatDateKey(selectedDate)] || []}
          onSave={(events) => handleSaveEvents(selectedDate, events)}
          onClose={() => setIsModalOpen(false)}
        />
      )}
      {pendingDeleteItem && (
        <div 
            className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
        >
            <div className="bg-[var(--color-bg-secondary)] rounded-xl shadow-2xl p-6 w-full max-w-sm text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
                    <AlertTriangleIcon className="h-6 w-6 text-red-600" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[var(--color-text-primary)]">Confirmar Exclusão</h3>
                <p className="mt-2 text-sm text-[var(--color-text-secondary)]">
                    Tem certeza de que deseja remover este item?
                </p>
                <div className="mt-6 flex justify-center gap-3">
                    <button 
                        onClick={() => setPendingDeleteItem(null)} 
                        className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)] transition-colors"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={confirmDeleteItem} 
                        className="px-4 py-2 rounded-md text-sm font-medium bg-red-600 text-white hover:bg-red-700 transition-colors"
                    >
                        Excluir
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}