import React, { useMemo, useState } from 'react';
import { Category, CheckedState, Frequency, Activity, MoodState, MoodLevel, Period, MoodEntry, SleepState, SleepType, DreamQualityLevel, SleepEntry } from '../types';
import ProgressBar from './ProgressBar';
import { getWeek } from '../utils/date';
import { getMoonPhase } from '../utils/moon';
import { ChartBarIcon, FireIcon, HeartIcon, SparklesIcon, FaceNeutralIcon, FaceMehIcon, FaceFrownIcon, QuestionMarkCircleIcon, ZzzIcon, MoonPauseIcon, EyeOffIcon, AlertTriangleIcon, FaceSmileIcon, StormIcon, CloudIcon, CloudOffIcon } from './Icons';

interface ReportsProps {
  categories: Category[];
  checkedState: CheckedState;
  moodState: MoodState;
  sleepState: SleepState;
}

const calculateCurrentStreak = (checkedDays: string[]): number => {
    if (!checkedDays || checkedDays.length === 0) return 0;

    const checksSet = new Set(checkedDays);
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayStr = today.toISOString().split('T')[0];
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    // Streak is current only if checked today or yesterday
    if (!checksSet.has(todayStr) && !checksSet.has(yesterdayStr)) {
        return 0;
    }

    let currentDay = new Date(today);
    // If not checked today, start counting from yesterday
    if(!checksSet.has(todayStr)) {
        currentDay = yesterday;
    }

    while (true) {
        const currentDayStr = currentDay.toISOString().split('T')[0];
        if (checksSet.has(currentDayStr)) {
            streak++;
            currentDay.setDate(currentDay.getDate() - 1);
        } else {
            break;
        }
    }
    return streak;
};

const calculateLongestStreak = (checkedDays: string[]): number => {
    if (!checkedDays || checkedDays.length < 1) return 0;

    const sortedDates = [...new Set(checkedDays)].map(d => new Date(d).getTime()).sort((a, b) => a - b);
    
    if (sortedDates.length === 1) return 1;

    let longestStreak = 0;
    let currentStreak = 1;
    
    for (let i = 1; i < sortedDates.length; i++) {
        const diff = (sortedDates[i] - sortedDates[i-1]) / (1000 * 60 * 60 * 24);
        if (diff === 1) {
            currentStreak++;
        } else {
            longestStreak = Math.max(longestStreak, currentStreak);
            currentStreak = 1;
        }
    }
    longestStreak = Math.max(longestStreak, currentStreak);
    return longestStreak;
};

// Updated moodLevelsMeta to match user's request
const moodLevelsMeta: { [key: number]: { Icon: React.ElementType, label: string, color: string, textColor: string, colorHex: string } } = {
  5: { Icon: HeartIcon, label: 'Pleno', color: 'bg-lime-300', textColor: 'text-lime-600', colorHex: '#d9f99d' },
  4: { Icon: SparklesIcon, label: 'Bem', color: 'bg-cyan-300', textColor: 'text-cyan-600', colorHex: '#a5f3fc' },
  3: { Icon: FaceNeutralIcon, label: 'Neutro', color: 'bg-yellow-300', textColor: 'text-yellow-600', colorHex: '#fef08a' },
  2: { Icon: FaceMehIcon, label: 'Mal', color: 'bg-orange-400', textColor: 'text-orange-600', colorHex: '#fb923c' },
  1: { Icon: FaceFrownIcon, label: 'Péssimo', color: 'bg-red-500', textColor: 'text-red-700', colorHex: '#ef4444' },
};

const sleepTypesMeta = {
    'uninterrupted': { Icon: ZzzIcon, label: 'Sono Inteiro', color: 'bg-blue-400', textColor: 'text-blue-600' },
    'interrupted': { Icon: MoonPauseIcon, label: 'Com Pausa', color: 'bg-indigo-300', textColor: 'text-indigo-500' },
    'difficult': { Icon: AlertTriangleIcon, label: 'Difícil', color: 'bg-amber-400', textColor: 'text-amber-600' },
    'sleepless': { Icon: EyeOffIcon, label: 'Noite em Claro', color: 'bg-slate-400', textColor: 'text-slate-600' },
};

const dreamQualityMeta = {
  '5': { Icon: FaceSmileIcon, label: 'Bom', color: 'bg-lime-400', textColor: 'text-lime-600' },
  '4': { Icon: SparklesIcon, label: 'Intuitivo', color: 'bg-cyan-400', textColor: 'text-cyan-600' },
  '3': { Icon: FaceNeutralIcon, label: 'Neutro', color: 'bg-yellow-400', textColor: 'text-yellow-600' },
  '2': { Icon: FaceFrownIcon, label: 'Incômodo', color: 'bg-orange-500', textColor: 'text-orange-700' },
  '1': { Icon: StormIcon, label: 'Pesadelo', color: 'bg-red-500', textColor: 'text-red-700' },
};

const calculateAverageMood = (entry: MoodEntry | undefined): MoodLevel | null => {
    if (!entry) return null;
    const levels = Object.values(entry).map(period => period!.level).filter(Boolean);
    if (levels.length === 0) return null;
    const sum = levels.reduce((a, b) => a + b, 0);
    const avg = sum / levels.length;
    return Math.round(avg) as MoodLevel;
};

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const LunarMandala: React.FC<{ moodState: MoodState; sleepState: SleepState }> = ({ moodState, sleepState }) => {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const dayElements = Array.from({ length: daysInMonth }, (_, i) => i + 1);
    
    const todayPhase = getMoonPhase(today);

    return (
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
            <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4 text-center">Mandala Lunar - {today.toLocaleDateString('pt-BR', { month: 'long' })}</h3>
            <div className="w-full max-w-sm mx-auto aspect-square relative flex items-center justify-center">
                <div className="absolute text-center">
                    <todayPhase.icon className="w-16 h-16 text-[var(--color-accent-text-faded)] mx-auto" />
                    <p className="text-sm font-bold mt-2">{todayPhase.name}</p>
                </div>

                {dayElements.map(dayNum => {
                    const angle = ((dayNum -1) / daysInMonth) * 2 * Math.PI - (Math.PI / 2); // Start from top
                    const radius = 45; // percentage
                    const x = 50 + radius * Math.cos(angle);
                    const y = 50 + radius * Math.sin(angle);
                    
                    const date = new Date(year, month, dayNum);
                    const key = formatDateKey(date);
                    const moodEntry = moodState[key];
                    const sleepEntry = sleepState[key];
                    
                    const avgMood = calculateAverageMood(moodEntry);
                    const moodColor = avgMood ? moodLevelsMeta[avgMood].colorHex : 'var(--color-bg-tertiary)';
                    
                    const sleepMeta = sleepEntry ? sleepTypesMeta[sleepEntry.type] : null;
                    const SleepIcon = sleepMeta?.Icon;

                    const phase = getMoonPhase(date);

                    return (
                        <div 
                            key={dayNum} 
                            className="absolute w-10 h-10 rounded-full group transition-transform hover:scale-110" 
                            style={{ 
                                top: `${y}%`, 
                                left: `${x}%`,
                                transform: 'translate(-50%, -50%)',
                                backgroundColor: moodColor,
                                border: dayNum === today.getDate() ? '2px solid var(--color-accent)' : '2px solid transparent'
                            }}
                        >
                            <div className="w-full h-full flex items-center justify-center relative">
                                <span className={`font-bold ${avgMood ? 'text-slate-800' : 'text-[var(--color-text-primary)]'}`}>{dayNum}</span>
                                {SleepIcon && <SleepIcon className="absolute top-0.5 right-0.5 w-3 h-3 text-white" style={{filter: 'drop-shadow(0 0 1px black)'}}/>}
                            </div>

                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-60 p-3 bg-[var(--color-bg-primary)] text-xs text-[var(--color-text-tertiary)] rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity duration-300 pointer-events-none z-10">
                                <p className="font-bold text-[var(--color-text-primary)] mb-1">{date.toLocaleDateString('pt-BR', {day: '2-digit', month: 'long'})} - {phase.name} {phase.emoji}</p>
                                <div className="space-y-1">
                                    <p><strong className="text-[var(--color-text-primary)]">Humor:</strong> {avgMood ? moodLevelsMeta[avgMood].label : 'N/A'}</p>
                                    <p><strong className="text-[var(--color-text-primary)]">Sono:</strong> {sleepMeta ? sleepMeta.label : 'N/A'}</p>
                                    {sleepEntry?.dream?.hadDream && (
                                        <p><strong className="text-[var(--color-text-primary)]">Sonho:</strong> {sleepEntry.dream.dreamQuality ? dreamQualityMeta[sleepEntry.dream.dreamQuality].label : 'Registrado'}</p>
                                    )}
                                </div>
                                <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-[var(--color-bg-primary)]"></div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};


export default function Reports({ categories, checkedState, moodState, sleepState }: ReportsProps): React.ReactElement {
  const [moodFilter, setMoodFilter] = useState<'currentMonth' | 'allTime'>('currentMonth');
  const [sleepFilter, setSleepFilter] = useState<'currentMonth' | 'allTime'>('currentMonth');

  const stats = useMemo(() => {
    const today = new Date();
    const currentMonthStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
    const allActivities = categories.flatMap(c => c.activities);
    
    let totalCompletedThisMonth = 0;
    
    const categoryPerformances = categories.map(category => {
        let catCompleted = 0;
        let catPossible = 0;
        
        category.activities.forEach(activity => {
            const checks = checkedState[activity.id] || [];
            
            if (activity.frequency === Frequency.DIARIO) {
                const daysSoFar = today.getDate();
                catPossible += daysSoFar;
                const completedThisMonth = checks.filter(key => key.startsWith(currentMonthStr) && new Date(key) <= today).length;
                catCompleted += completedThisMonth;
                totalCompletedThisMonth += completedThisMonth;
            } else if (activity.frequency === Frequency.SEMANAL) {
                const targetPerWeek = activity.target || 1;
                const weeksInMonthSoFar = [...new Set(
                    Array.from({ length: today.getDate() }, (_, i) => {
                        const d = new Date(today.getFullYear(), today.getMonth(), i + 1);
                        return `${d.getFullYear()}-${getWeek(d)}`;
                    })
                )];
                
                catPossible += weeksInMonthSoFar.length * targetPerWeek;
                const completedThisMonth = checks.filter(key => weeksInMonthSoFar.includes(key)).length;
                catCompleted += completedThisMonth;
                totalCompletedThisMonth += completedThisMonth;
            } else if (activity.frequency === Frequency.MENSAL) {
                const target = activity.target || 1;
                catPossible += target;
                const completedThisMonth = checks.filter(key => key === currentMonthStr).length;
                catCompleted += completedThisMonth;
                totalCompletedThisMonth += completedThisMonth;
            }
        });

        const percentage = catPossible > 0 ? (catCompleted / catPossible) * 100 : 0;
        return { ...category, percentage };
    });
    
    const totalPossibleOverall = categoryPerformances.reduce((acc, cat) => {
      let catPossible = 0;
       cat.activities.forEach(activity => {
            if (activity.frequency === Frequency.DIARIO) {
                catPossible += today.getDate();
            } else if (activity.frequency === Frequency.SEMANAL) {
                const targetPerWeek = activity.target || 1;
                const weeksInMonthSoFar = [...new Set(
                    Array.from({ length: today.getDate() }, (_, i) => {
                        const d = new Date(today.getFullYear(), today.getMonth(), i + 1);
                        return `${d.getFullYear()}-${getWeek(d)}`;
                    })
                )];
                catPossible += weeksInMonthSoFar.length * targetPerWeek;
            } else if (activity.frequency === Frequency.MENSAL) {
                const target = activity.target || 1;
                catPossible += target;
            }
        });
        return acc + catPossible;
    }, 0);


    const overallCompletion = totalPossibleOverall > 0 ? (totalCompletedThisMonth / totalPossibleOverall) * 100 : 0;

    const dailyActivities = allActivities.filter(a => a.frequency === Frequency.DIARIO);
    const habitStreaks = dailyActivities.map(activity => ({
        ...activity,
        currentStreak: calculateCurrentStreak(checkedState[activity.id] || []),
        longestStreak: calculateLongestStreak(checkedState[activity.id] || []),
    })).sort((a,b) => b.currentStreak - a.currentStreak);

    const bestStreakEver = Math.max(0, ...habitStreaks.map(h => h.longestStreak));
    
    // Mood Stats Calculation
    const filteredMoodEntries = Object.entries(moodState)
        .filter(([date]) => {
            if (moodFilter === 'currentMonth') {
                return date.startsWith(currentMonthStr) && new Date(date) <= today;
            }
            return true; // allTime
        });

    const allMoodLevelsInPeriod = filteredMoodEntries.flatMap(([, entry]) => 
        (Object.keys(entry) as Period[]).map(periodKey => entry[periodKey]!.level)
    );

    const moodDistribution = (Object.keys(moodLevelsMeta) as unknown as MoodLevel[]).map(level => {
        const count = allMoodLevelsInPeriod.filter(l => l === Number(level)).length;
        return {
            level,
            count,
            percentage: allMoodLevelsInPeriod.length > 0 ? (count / allMoodLevelsInPeriod.length) * 100 : 0,
        };
    }).sort((a, b) => Number(b.level) - Number(a.level));

     // Sleep Stats Calculation
    const filteredSleepEntries = Object.entries(sleepState)
        .filter(([date]) => {
            if (sleepFilter === 'currentMonth') {
                return date.startsWith(currentMonthStr) && new Date(date) <= today;
            }
            return true; // allTime
        });

    const allSleepTypesInPeriod = filteredSleepEntries.map(([, entry]) => entry.type);

    const sleepDistribution = (Object.keys(sleepTypesMeta) as SleepType[]).map(type => {
        const count = allSleepTypesInPeriod.filter(t => t === type).length;
        return {
            type,
            count,
            percentage: allSleepTypesInPeriod.length > 0 ? (count / allSleepTypesInPeriod.length) * 100 : 0,
        };
    });

    // Dream Stats Calculation
    const nightsWithDreams = filteredSleepEntries.filter(([, entry]) => entry.dream?.hadDream).length;
    const nightsWithoutDreams = filteredSleepEntries.filter(([, entry]) => entry.dream?.hadDream === false).length;
    const totalNightsWithDreamLog = nightsWithDreams + nightsWithoutDreams;

    const allDreamQualitiesInPeriod = filteredSleepEntries
        .map(([, entry]) => entry.dream?.dreamQuality)
        .filter((quality): quality is DreamQualityLevel => quality !== undefined);

    const dreamQualityDistribution = (Object.keys(dreamQualityMeta) as unknown as DreamQualityLevel[]).map(level => {
        const count = allDreamQualitiesInPeriod.filter(q => q === Number(level)).length;
        return {
            level,
            count,
            percentage: allDreamQualitiesInPeriod.length > 0 ? (count / allDreamQualitiesInPeriod.length) * 100 : 0,
        };
    }).sort((a, b) => Number(b.level) - Number(a.level));


    return {
      overallCompletion,
      totalCompletedThisMonth,
      categoryPerformances,
      habitStreaks,
      bestStreakEver,
      moodDistribution,
      totalMoodDays: allMoodLevelsInPeriod.length,
      sleepDistribution,
      totalSleepDays: allSleepTypesInPeriod.length,
      nightsWithDreams,
      nightsWithoutDreams,
      totalNightsWithDreamLog,
      dreamQualityDistribution,
      totalDreamQualityLogs: allDreamQualitiesInPeriod.length,
    };

  }, [categories, checkedState, moodState, moodFilter, sleepState, sleepFilter]);
  
  return (
    <div className="space-y-8 ml-0 pt-16 md:pt-0">
      <header>
        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Relatório de Performance</h2>
        <p className="mt-1 text-[var(--color-text-secondary)]">Analise seu progresso e consistência ao longo do tempo.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-[var(--color-text-tertiary)]">Progresso Geral (Mês)</h3>
            <p className="text-4xl font-bold text-[var(--color-accent-text)] mt-2">{stats.overallCompletion.toFixed(0)}%</p>
          </div>
          <div className="mt-4">
            <ProgressBar progress={stats.overallCompletion} />
          </div>
        </div>
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
          <h3 className="font-semibold text-[var(--color-text-tertiary)]">Total de Conclusões</h3>
          <p className="text-4xl font-bold text-[var(--color-accent-text)] mt-2">{stats.totalCompletedThisMonth}</p>
          <p className="text-sm text-[var(--color-text-secondary)]">neste mês.</p>
        </div>
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
          <h3 className="font-semibold text-[var(--color-text-tertiary)]">Maior Sequência Geral</h3>
          <p className="text-4xl font-bold text-[var(--color-accent-text)] mt-2 flex items-center gap-2">
            <FireIcon className="h-8 w-8" />
            {stats.bestStreakEver}
          </p>
          <p className="text-sm text-[var(--color-text-secondary)]">dias consecutivos.</p>
        </div>
      </div>
      
      <LunarMandala moodState={moodState} sleepState={sleepState} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
          <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">Performance por Setor</h3>
          <div className="space-y-4">
            {stats.categoryPerformances.map(cat => (
              <div key={cat.id}>
                <div className="flex justify-between items-center mb-1 text-sm">
                  <div className="flex items-center gap-2 font-medium text-[var(--color-text-tertiary)]">
                    <cat.icon className="w-4 h-4" />
                    <span>{cat.name}</span>
                  </div>
                  <span className="font-semibold text-[var(--color-text-primary)]">{cat.percentage.toFixed(0)}%</span>
                </div>
                <ProgressBar progress={cat.percentage} small />
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
            <h3 className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">Consistência (Hábitos Diários)</h3>
            <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
                {stats.habitStreaks.map(habit => (
                <div key={habit.id} className="flex items-center justify-between text-sm p-3 bg-[var(--color-bg-tertiary)] rounded-lg">
                    <span className="text-[var(--color-text-primary)] truncate pr-2">{habit.name}</span>
                    <div className="flex items-center gap-3 flex-shrink-0">
                        <div className="text-right">
                            <span className="font-bold text-[var(--color-accent-text)]">{habit.currentStreak} dias</span>
                            <span className="text-xs text-[var(--color-text-secondary)] block">Sequência</span>
                        </div>
                        <div className="text-right pl-3 border-l border-[var(--color-border)]">
                            <span className="font-bold text-[var(--color-text-secondary)]">{habit.longestStreak} dias</span>
                            <span className="text-xs text-[var(--color-text-secondary)] block">Recorde</span>
                        </div>
                    </div>
                </div>
                ))}
                {stats.habitStreaks.length === 0 && <p className="text-sm text-[var(--color-text-secondary)] text-center py-4">Nenhum hábito diário para analisar.</p>}
            </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                        <h3 className="text-xl font-semibold text-[var(--color-text-primary)]">Resumo de Humor</h3>
                        <div className="relative group flex items-center">
                            <QuestionMarkCircleIcon className="w-5 h-5 text-[var(--color-text-secondary)] cursor-help" />
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-[var(--color-bg-primary)] text-xs text-[var(--color-text-tertiary)] rounded-lg shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity duration-300 pointer-events-none z-10">
                                Este gráfico mostra a distribuição de todos os seus registros de humor (manhã, tarde, noite) no período.
                                <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-[var(--color-bg-primary)]"></div>
                            </div>
                        </div>
                    </div>
                    <select
                        value={moodFilter}
                        onChange={(e) => setMoodFilter(e.target.value as 'currentMonth' | 'allTime')}
                        className="bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-1 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                        aria-label="Filtrar período do resumo de humor"
                    >
                        <option value="currentMonth">Este Mês</option>
                        <option value="allTime">Todo o Período</option>
                    </select>
                </div>
                {stats.totalMoodDays > 0 ? (
                    <div className="space-y-3">
                        {stats.moodDistribution.map(({ level, count, percentage }) => {
                            const { Icon, label, color, textColor } = moodLevelsMeta[level as unknown as MoodLevel];
                            return (
                                <div key={level} className="flex items-center gap-3 text-sm">
                                    <Icon className={`w-5 h-5 flex-shrink-0 ${textColor}`} />
                                    <div className="w-20 text-[var(--color-text-secondary)] truncate">{label}</div>
                                    <div className="flex-grow bg-[var(--color-bg-tertiary)] rounded-full h-4">
                                        <div className={`${color} h-4 rounded-full text-white flex items-center justify-end pr-2 text-xs font-bold`} style={{ width: `${percentage}%` }}>
                                            {percentage > 15 ? `${percentage.toFixed(0)}%` : ''}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <p className="text-sm text-[var(--color-text-secondary)] text-center py-4">Nenhum humor registrado para o período selecionado.</p>
                )}
            </div>

            <div className="bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg">
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-[var(--color-text-primary)]">Resumo de Sono</h3>
                     <select
                        value={sleepFilter}
                        onChange={(e) => setSleepFilter(e.target.value as 'currentMonth' | 'allTime')}
                        className="bg-[var(--color-bg-tertiary)] border border-[var(--color-border-input)] text-sm rounded-md p-1 focus:ring-1 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                        aria-label="Filtrar período do resumo de sono"
                    >
                        <option value="currentMonth">Este Mês</option>
                        <option value="allTime">Todo o Período</option>
                    </select>
                </div>
                 {stats.totalSleepDays > 0 ? (
                    <>
                        <div className="space-y-3">
                            {stats.sleepDistribution.map(({ type, count, percentage }) => {
                                const { Icon, label, color, textColor } = sleepTypesMeta[type as SleepType];
                                return (
                                    <div key={type} className="flex items-center gap-3 text-sm">
                                        <Icon className={`w-5 h-5 flex-shrink-0 ${textColor}`} />
                                        <div className="w-24 text-[var(--color-text-secondary)] truncate">{label}</div>
                                        <div className="flex-grow bg-[var(--color-bg-tertiary)] rounded-full h-4">
                                            <div className={`${color} h-4 rounded-full text-white flex items-center justify-end pr-2 text-xs font-bold`} style={{ width: `${percentage}%` }}>
                                                 {percentage > 15 ? `${percentage.toFixed(0)}%` : ''}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        {stats.totalNightsWithDreamLog > 0 && (
                            <div className="mt-6 pt-4 border-t border-[var(--color-border)]">
                                <h4 className="text-lg font-semibold text-[var(--color-text-primary)] mb-3">Resumo de Sonhos</h4>
                                <div className="flex gap-4 mb-4 text-sm">
                                    <div className="flex-1 p-3 bg-[var(--color-bg-tertiary)] rounded-lg flex items-center gap-2">
                                        <CloudIcon className="w-5 h-5 text-green-500"/>
                                        <div>
                                            <span className="font-bold">{stats.nightsWithDreams}</span> noites
                                            <span className="block text-xs text-[var(--color-text-secondary)]">Com Sonho</span>
                                        </div>
                                    </div>
                                    <div className="flex-1 p-3 bg-[var(--color-bg-tertiary)] rounded-lg flex items-center gap-2">
                                        <CloudOffIcon className="w-5 h-5 text-red-500"/>
                                        <div>
                                            <span className="font-bold">{stats.nightsWithoutDreams}</span> noites
                                            <span className="block text-xs text-[var(--color-text-secondary)]">Sem Sonho</span>
                                        </div>
                                    </div>
                                </div>
                                {stats.totalDreamQualityLogs > 0 && (
                                    <div className="space-y-3">
                                        {stats.dreamQualityDistribution.map(({ level, count, percentage }) => {
                                            const { Icon, label, color, textColor } = dreamQualityMeta[level as unknown as DreamQualityLevel];
                                            return (
                                                <div key={level} className="flex items-center gap-3 text-sm">
                                                    <Icon className={`w-5 h-5 flex-shrink-0 ${textColor}`} />
                                                    <div className="w-24 text-[var(--color-text-secondary)] truncate">{label}</div>
                                                    <div className="flex-grow bg-[var(--color-bg-tertiary)] rounded-full h-4">
                                                        <div className={`${color} h-4 rounded-full text-white flex items-center justify-end pr-2 text-xs font-bold`} style={{ width: `${percentage}%` }}>
                                                            {percentage > 15 ? `${percentage.toFixed(0)}%` : ''}
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        )}
                    </>
                ) : (
                    <p className="text-sm text-[var(--color-text-secondary)] text-center py-4">Nenhum registro de sono para o período selecionado.</p>
                )}
            </div>
      </div>
    </div>
  );
}