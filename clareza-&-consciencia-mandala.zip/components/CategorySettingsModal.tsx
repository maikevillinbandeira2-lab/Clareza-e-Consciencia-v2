import React, { useState } from 'react';
import { Category } from '../types';
import { XIcon } from './Icons';

interface CategorySettingsModalProps {
  activeCategories: Category[];
  allCategories: Category[];
  onClose: () => void;
  onSave: (selectedIds: string[]) => void;
}

export default function CategorySettingsModal({ activeCategories, allCategories, onClose, onSave }: CategorySettingsModalProps): React.ReactElement {
  const [selectedIds, setSelectedIds] = useState(() => new Set(activeCategories.map(c => c.id)));

  const handleToggle = (categoryId: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  const handleSave = () => {
    onSave(Array.from(selectedIds));
  };

  return (
    <div 
      className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="category-settings-title"
    >
      <div 
        className="bg-[var(--color-bg-secondary)] w-full max-w-md max-h-[90vh] rounded-2xl shadow-2xl p-6 md:p-8 flex flex-col relative overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex-shrink-0 flex justify-between items-center pb-4 border-b border-[var(--color-border)]">
          <h2 id="category-settings-title" className="text-xl md:text-2xl font-bold text-[var(--color-text-primary)]">
            Gerenciar Setores da Vida
          </h2>
          <button 
            onClick={onClose} 
            className="p-2 rounded-full text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)] transition-colors"
            aria-label="Fechar"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto pr-2 -mr-4 my-6 text-base text-[var(--color-text-tertiary)] space-y-2">
            <p className="text-sm text-[var(--color-text-secondary)] mb-4">Selecione os setores que você deseja acompanhar no seu painel.</p>
            {allCategories.map(category => (
                 <label key={category.id} htmlFor={`cat-check-${category.id}`} className="flex p-3 rounded-lg hover:bg-[var(--color-bg-tertiary)] cursor-pointer transition-colors">
                     <input
                         type="checkbox"
                         id={`cat-check-${category.id}`}
                         checked={selectedIds.has(category.id)}
                         onChange={() => handleToggle(category.id)}
                         className="h-5 w-5 rounded border-[var(--color-border-input)] text-[var(--color-accent)] focus:ring-[var(--color-accent)] bg-transparent mt-1"
                     />
                     <div className="ml-3">
                        <div className="flex items-center">
                          <category.icon className="w-5 h-5 mr-2 text-[var(--color-text-secondary)]"/>
                          <span className="text-sm font-medium text-[var(--color-text-primary)]">{category.name}</span>
                        </div>
                        {category.description && <p className="text-xs text-[var(--color-text-secondary)] mt-1">{category.description}</p>}
                     </div>
                 </label>
            ))}
        </div>

        <div className="flex-shrink-0 flex justify-end items-center pt-6 border-t border-[var(--color-border)] gap-3">
            <button 
                onClick={onClose}
                className="px-4 py-2 rounded-md text-sm font-medium text-[var(--color-text-secondary)] bg-[var(--color-bg-tertiary)] hover:bg-[var(--color-border)]"
            >
                Cancelar
            </button>
            <button 
                onClick={handleSave}
                className="bg-[var(--color-accent)] text-[var(--color-bg-primary)] font-bold py-2 px-6 rounded-lg hover:opacity-90 transition-opacity"
            >
                Salvar
            </button>
        </div>
      </div>
    </div>
  );
}