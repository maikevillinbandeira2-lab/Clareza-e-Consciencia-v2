import React, { useState, useMemo, useEffect } from 'react';
import { MoodState, MoodEntry, MoodLevel, Period } from '../types';
import { ChevronLeftIcon, ChevronRightIcon, TrashIcon, FaceFrownIcon, FaceMehIcon, SparklesIcon, HeartIcon, FaceNeutralIcon, AlertTriangleIcon, PencilIcon, CheckIcon, XIcon } from './Icons';

interface MoodTrackerProps {
  moodState: MoodState;
  onUpdate: (newState: MoodState) => void;
}

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const moodOptions: { [key: string]: { label: string; Icon: React.ElementType; description: string; colorClass: string; hoverColorClass: string; ringColorClass: string; textColorClass: string; colorHex: string; } } = {
    '5': { 
        label: 'Pleno', 
        Icon: HeartIcon, 
        description: 'Sensação de paz, gratidão e plenitude.',
        colorClass: 'bg-lime-300', 
        hoverColorClass: 'hover:bg-lime-400', 
        ringColorClass: 'ring-lime-400', 
        textColorClass: 'text-lime-600', 
        colorHex: '#a3e635' 
    },
    '4': { 
        label: 'Bem', 
        Icon: SparklesIcon, 
        description: 'Sentindo-se confiante, criativo e com energia.',
        colorClass: 'bg-cyan-300', 
        hoverColorClass: 'hover:bg-cyan-400', 
        ringColorClass: 'ring-cyan-400', 
        textColorClass: 'text-cyan-600', 
        colorHex: '#67e8f9' 
    },
    '3': { 
        label: 'Neutro', 
        Icon: FaceNeutralIcon, 
        description: 'Um estado de equilíbrio, sem grandes picos emocionais.',
        colorClass: 'bg-yellow-300', 
        hoverColorClass: 'hover:bg-yellow-400', 
        ringColorClass: 'ring-yellow-400', 
        textColorClass: 'text-yellow-600', 
        colorHex: '#fde047' 
    },
    '2': { 
        label: 'Mal', 
        Icon: FaceMehIcon, 
        description: 'Presença de tristeza, ansiedade ou frustração.',
        colorClass: 'bg-orange-400', 
        hoverColorClass: 'hover:bg-orange-500', 
        ringColorClass: 'ring-orange-500', 
        textColorClass: 'text-orange-600', 
        colorHex: '#fb923c' 
    },
    '1': { 
        label: 'Péssimo', 
        Icon: FaceFrownIcon, 
        description: 'Sentimentos intensos de desânimo, medo ou angústia.',
        colorClass: 'bg-red-500',
        hoverColorClass: 'hover:bg-red-600',
        ringColorClass: 'ring-red-600',
        textColorClass: 'text-red-700',
        colorHex: '#ef4444'
    },
};


const periods: { key: Period; label: string }[] = [
    { key: 'morning', label: 'Manhã' },
    { key: 'afternoon', label: 'Tarde' },
    { key: 'night', label: 'Noite' },
];

const MoodPieDisplay: React.FC<{ entry: MoodEntry }> = ({ entry }) => {
    const filledPeriods = periods.filter(p => entry[p.key]);
    if (filledPeriods.length === 0) return null;

    const colors = filledPeriods.map(p => moodOptions[entry[p.key]!.level].colorHex);
    
    const gradientParts: string[] = [];
    if (colors.length === 1) {
        gradientParts.push(colors[0]);
    } else {
        const sliceAngle = 360 / colors.length;
        colors.forEach((color, i) => {
            gradientParts.push(`${color} ${i * sliceAngle}deg, ${color} ${(i + 1) * sliceAngle}deg`);
        });
    }

    const style = {
        background: colors.length === 1 ? colors[0] : `conic-gradient(${gradientParts.join(', ')})`,
    };

    return <div className="w-full h-full rounded-full" style={style}></div>;
};

export default function MoodTracker({ moodState, onUpdate }: MoodTrackerProps): React.ReactElement {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<Date>(new Date());
  const [selectedPeriod, setSelectedPeriod] = useState<Period>('morning');
  const [isEditing, setIsEditing] = useState(false);
  const [localEntry, setLocalEntry] = useState<MoodEntry | undefined>(undefined);
  
  const selectedDayKey = formatDateKey(selectedDay);
  const currentDayMoods = moodState[selectedDayKey];

  useEffect(() => {
    const entry = moodState[selectedDayKey];
    setLocalEntry(entry);
    setIsEditing(false); // Default to view mode
    setSelectedPeriod('morning'); // Reset to morning tab
  }, [selectedDay, moodState, selectedDayKey]);


  const monthGrid = useMemo(() => {
    const date = new Date(currentDate);
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const startDate = new Date(firstDayOfMonth);
    startDate.setDate(startDate.getDate() - startDate.getDay());

    const days = [];
    for (let i = 0; i < 42; i++) {
      days.push(new Date(startDate));
      startDate.setDate(startDate.getDate() + 1);
    }
    return days;
  }, [currentDate]);

  const handlePrevMonth = () => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(newDate.getMonth() - 1);
      return newDate;
    });
  };

  const handleNextMonth = () => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(newDate.getMonth() + 1);
      return newDate;
    });
  };

  const handleSelectMood = (level: MoodLevel) => {
    setLocalEntry(prev => ({
        ...(prev || {}),
        [selectedPeriod]: { level },
    }));
  };

  const handleDeleteMoodForPeriod = () => {
      if (!localEntry) return;
      const updatedEntry = { ...localEntry };
      delete updatedEntry[selectedPeriod];
      setLocalEntry(updatedEntry);
  };
  
  const handleSave = () => {
      const newState = { ...moodState };
      if (localEntry && Object.keys(localEntry).length > 0) {
          newState[selectedDayKey] = localEntry;
      } else {
          delete newState[selectedDayKey];
      }
      onUpdate(newState);
      setIsEditing(false);
  };

  const handleCancel = () => {
      setLocalEntry(currentDayMoods); // Revert changes
      setIsEditing(false);
  };
  
  return (
    <div className="h-full flex flex-col pt-16 md:pt-0">
      <header>
        <h2 className="text-3xl font-bold text-[var(--color-text-primary)] tracking-tight">Controle de Humor</h2>
        <p className="mt-1 text-[var(--color-text-secondary)]">Registre seu estado emocional diário para encontrar padrões.</p>
      </header>

      <div className="flex-grow mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[var(--color-bg-secondary)] p-4 sm:p-6 rounded-xl shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronLeftIcon className="w-5 h-5"/></button>
                <h3 className="text-lg font-semibold text-center capitalize">{currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h3>
                <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-[var(--color-bg-tertiary)]"><ChevronRightIcon className="w-5 h-5"/></button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center">
                 {WEEKDAYS.map(day => <div key={day} className="text-xs font-bold text-[var(--color-text-secondary)] py-2">{day}</div>)}
                 {monthGrid.map((day, i) => {
                     const key = formatDateKey(day);
                     const moodEntry = moodState[key];
                     const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                     const isSelected = key === selectedDayKey;
                     const isToday = key === formatDateKey(new Date());

                     return (
                         <div key={i} onClick={() => setSelectedDay(day)} className={`h-12 sm:h-16 rounded-lg cursor-pointer flex items-center justify-center transition-all duration-200 border-2 ${isSelected ? 'border-[var(--color-accent)]' : 'border-transparent'}`}>
                             <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex flex-col items-center justify-center transition-colors`}>
                                {moodEntry && Object.keys(moodEntry).length > 0 ? (
                                    <div className="w-full h-full rounded-full relative">
                                        <MoodPieDisplay entry={moodEntry} />
                                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-full">
                                            <span className={`font-semibold text-white ${isToday ? 'relative' : ''}`}>
                                                {day.getDate()}
                                                {isToday && <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>}
                                            </span>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="w-full h-full rounded-full flex items-center justify-center bg-[var(--color-bg-tertiary)]">
                                        <span className={`font-semibold ${isCurrentMonth ? 'text-[var(--color-text-primary)]' : 'text-gray-500'} ${isToday ? 'relative' : ''}`}>
                                            {day.getDate()}
                                            {isToday && <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-[var(--color-accent)] rounded-full"></div>}
                                        </span>
                                    </div>
                                )}
                             </div>
                         </div>
                     );
                 })}
            </div>
        </div>

        <div className="lg:col-span-1 bg-[var(--color-bg-secondary)] p-6 rounded-xl shadow-lg flex flex-col">
            <h3 className="text-xl font-bold text-center text-[var(--color-text-primary)]">
                {selectedDay.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' })}
            </h3>
            
            {isEditing ? (
                // EDIT MODE
                <div className="my-6 flex-grow flex flex-col">
                    <div className="flex justify-center border border-[var(--color-border)] rounded-lg p-1 mb-4">
                        {periods.map(({ key, label }) => (
                            <button
                                key={key}
                                onClick={() => setSelectedPeriod(key)}
                                className={`flex-1 px-3 py-1.5 text-sm font-semibold rounded-md transition-colors ${
                                    selectedPeriod === key
                                    ? 'bg-[var(--color-accent)] text-[var(--color-bg-primary)]'
                                    : 'text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)]'
                                }`}
                            >
                                {label}
                            </button>
                        ))}
                    </div>
                    <p className="text-sm font-medium text-center text-[var(--color-text-secondary)] mb-4">Como você se sentiu no período de {selectedPeriod === 'morning' ? 'manhã' : selectedPeriod === 'afternoon' ? 'tarde' : 'noite'}?</p>
                    <div className="flex justify-around">
                        {Object.entries(moodOptions).reverse().map(([level, {Icon, hoverColorClass, ringColorClass, textColorClass, colorClass}]) => {
                            const isSelected = localEntry?.[selectedPeriod]?.level === Number(level);
                            return (
                                <button key={level} onClick={() => handleSelectMood(Number(level) as MoodLevel)} className={`p-2 rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[var(--color-bg-secondary)] ${hoverColorClass} ${isSelected ? `${colorClass} ${ringColorClass} ring-2` : 'bg-transparent'}`} aria-label={moodOptions[level as keyof typeof moodOptions].label}>
                                <Icon className={`w-8 h-8 ${isSelected ? 'text-white' : textColorClass}`}/>
                                </button>
                            );
                        })}
                    </div>
                    {localEntry?.[selectedPeriod] && (
                        <div className="text-center mt-4">
                            <button onClick={handleDeleteMoodForPeriod} className="text-xs text-red-500 hover:underline">
                                Limpar registro de {selectedPeriod === 'morning' ? 'manhã' : selectedPeriod === 'afternoon' ? 'tarde' : 'noite'}
                            </button>
                        </div>
                    )}
                    <div className="mt-auto pt-4 space-x-2 flex justify-end">
                        <button onClick={handleCancel} className="px-4 py-2 text-sm font-medium rounded-md hover:bg-[var(--color-bg-tertiary)]">Cancelar</button>
                        <button onClick={handleSave} className="px-4 py-2 text-sm font-semibold rounded-md bg-[var(--color-accent)] text-[var(--color-bg-primary)] hover:opacity-90">Salvar</button>
                    </div>
                </div>
            ) : (
                // VIEW MODE
                <div className="my-6 flex-grow flex flex-col">
                    <div className="flex-grow space-y-3">
                        {periods.map(({key, label}) => {
                            const mood = currentDayMoods?.[key];
                            if (mood) {
                                const { Icon, label: moodLabel, colorClass } = moodOptions[mood.level];
                                return (
                                    <div key={key} className="p-3 bg-[var(--color-bg-tertiary)] rounded-lg flex items-center justify-between">
                                        <span className="font-semibold text-sm text-[var(--color-text-primary)]">{label}</span>
                                        <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-bold ${colorClass}`}>
                                            <Icon className="w-5 h-5"/>
                                            <span>{moodLabel}</span>
                                        </div>
                                    </div>
                                );
                            }
                            return (
                                <div key={key} className="p-3 bg-[var(--color-bg-tertiary)] rounded-lg flex items-center justify-between opacity-60">
                                    <span className="font-semibold text-sm text-[var(--color-text-secondary)]">{label}</span>
                                    <span className="text-xs text-[var(--color-text-secondary)]">Nenhum registro</span>
                                </div>
                            );
                        })}
                    </div>
                    <button onClick={() => setIsEditing(true)} className="mt-6 w-full flex items-center justify-center gap-2 text-sm font-semibold py-2 px-4 rounded-md text-[var(--color-accent-text)] bg-[var(--color-accent-bg-subtle)] hover:opacity-90 transition-opacity">
                        <PencilIcon className="w-4 h-4" />
                        {currentDayMoods ? 'Editar' : 'Adicionar Registro'}
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
}