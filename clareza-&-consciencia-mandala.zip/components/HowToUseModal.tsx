import React from 'react';
import { XIcon } from './Icons';

interface HowToUseModalProps {
  onClose: () => void;
}

export default function HowToUseModal({ onClose }: HowToUseModalProps): React.ReactElement {
  return (
    <div 
      className="fixed inset-0 bg-black/70 z-50 flex justify-center items-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="how-to-use-title"
    >
      <div 
        className="bg-[var(--color-bg-secondary)] w-full max-w-2xl max-h-[90vh] rounded-2xl shadow-2xl p-6 md:p-8 flex flex-col relative overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex-shrink-0 flex justify-between items-center pb-4 border-b border-[var(--color-border)]">
          <h2 id="how-to-use-title" className="text-xl md:text-2xl font-bold text-[var(--color-text-primary)]">
            O Caminho da Clareza
          </h2>
          <button 
            onClick={onClose} 
            className="p-2 rounded-full text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-tertiary)] hover:text-[var(--color-text-primary)] transition-colors"
            aria-label="Fechar"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto pr-2 -mr-4 mt-6 text-base text-[var(--color-text-tertiary)] space-y-6">
          <section>
            <h3 className="text-lg font-semibold text-[var(--color-text-primary)] mb-2">Você é o Observador</h3>
            <p>
              Você é o centro da sua jornada. Este painel é um espelho, uma ferramenta para iluminar seus padrões e cultivar a consciência. Observe seus hábitos e emoções sem julgamento, com clareza.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-[var(--color-text-primary)] mb-2">A Jornada Diária: Clareza e Consciência</h3>
            <p>O propósito desta ferramenta é trazer clareza sobre sua jornada. O verdadeiro crescimento vem da auto-observação consistente. Use este painel para:</p>
            <ul className="list-disc list-inside space-y-2 mt-4">
                <li><strong className="text-[var(--color-text-primary)]">Observar:</strong> Registre seus hábitos, humores e conquistas diariamente. O simples ato de anotar cria consciência.</li>
                <li><strong className="text-[var(--color-text-primary)]">Medir:</strong> Acompanhe seu progresso nos relatórios. Os dados mostram a realidade dos seus padrões, além da percepção.</li>
                <li><strong className="text-[var(--color-text-primary)]">Avaliar:</strong> Com os dados em mãos, reflita: Você está caminhando na direção dos seus objetivos? Onde você pode ajustar a rota?</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-[var(--color-text-primary)] mb-4">Definindo Seus Objetivos</h3>
             <p>Seus objetivos são a bússola da sua jornada. Eles representam o que você deseja <strong className="text-[var(--color-text-primary)]">Ser</strong> ou as habilidades que quer <strong className="text-[var(--color-text-primary)]">Desenvolver</strong>. Pense neles não como tarefas, mas como transformações:</p>
            <ul className="list-disc list-inside space-y-2 mt-4 text-[var(--color-text-secondary)]">
                <li>"<strong className="text-[var(--color-text-primary)]">Ser</strong> mais paciente e presente."</li>
                <li>"<strong className="text-[var(--color-text-primary)]">Desenvolver</strong> a habilidade de comunicação não-violenta."</li>
                <li>"<strong className="text-[var(--color-text-primary)]">Se tornar</strong> uma pessoa que se exercita regularmente e cuida da saúde."</li>
            </ul>
            <p className="mt-4">Os <strong className="text-[var(--color-text-primary)]">Setores da Vida</strong> te ajudam a organizar esses objetivos, e as atividades diárias, semanais e mensais são os pequenos passos que te levarão até eles.</p>
          </section>

          <section>
            <h3 className="text-lg font-semibold text-[var(--color-text-primary)] mb-2">A Colheita da Consciência</h3>
            <p>
              A consistência na sua jornada diária traz clareza. Os relatórios são o espelho do seu progresso, mostrando o que está funcionando. Use esses insights para tomar decisões conscientes e continuar sua jornada de crescimento e autoconhecimento.
            </p>
          </section>
        </div>

        <div className="flex-shrink-0 pt-6 text-center">
            <button 
                onClick={onClose}
                className="bg-[var(--color-accent)] text-[var(--color-bg-primary)] font-bold py-2 px-6 rounded-lg hover:opacity-90 transition-opacity"
            >
                Entendido
            </button>
        </div>
      </div>
    </div>
  );
}