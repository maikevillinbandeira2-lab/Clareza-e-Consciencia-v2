import { MoonPhase } from '../types';
import { NewMoonIcon, WaxingCrescentIcon, FirstQuarterIcon, WaxingGibbousIcon, FullMoonIcon, WaningGibbousIcon, ThirdQuarterIcon, WaningCrescentIcon } from '../components/Icons';
import { getWeek } from './date';

const MOON_PHASES: MoonPhase[] = [
    { name: "Lua Nova", icon: NewMoonIcon, emoji: "🌑" },
    { name: "Lua Crescente", icon: WaxingCrescentIcon, emoji: "🌒" },
    { name: "Quarto Crescente", icon: FirstQuarterIcon, emoji: "🌓" },
    { name: "Gibosa Crescente", icon: WaxingGibbousIcon, emoji: "🌔" },
    { name: "Lua Cheia", icon: FullMoonIcon, emoji: "🌕" },
    { name: "Gibosa Minguante", icon: WaningGibbousIcon, emoji: "🌖" },
    { name: "Quarto Minguante", icon: ThirdQuarterIcon, emoji: "🌗" },
    { name: "Lua Minguante", icon: WaningCrescentIcon, emoji: "🌘" },
];

const SYNODIC_MONTH = 29.53058867;

// Known new moon: January 21, 2023, 20:53 UTC
const KNOWN_NEW_MOON = new Date('2023-01-21T20:53:00Z');

const daysSinceKnownNewMoon = (date: Date): number => {
    const msPerDay = 1000 * 60 * 60 * 24;
    return (date.getTime() - KNOWN_NEW_MOON.getTime()) / msPerDay;
}

export const getMoonPhase = (date: Date): MoonPhase => {
    const days = daysSinceKnownNewMoon(date);
    const phase = (days / SYNODIC_MONTH) % 1;
    const index = Math.floor(phase * 8 + 0.5) & 7;
    return MOON_PHASES[index];
};

const SKY_OF_THE_WEEK_MESSAGES = [
    "Energias de renovação estão no ar. É um momento ideal para iniciar projetos e plantar novas sementes para o futuro. A clareza mental está em alta.",
    "A comunicação é a chave desta semana. Expresse suas ideias e ouça ativamente. Conexões importantes podem surgir de conversas sinceras.",
    "Foco na organização e na estrutura. Crie planos sólidos e detalhados. A disciplina agora trará grandes recompensas mais tarde.",
    "Momento de introspecção e cuidado pessoal. Ouça sua intuição e reserve tempo para recarregar as energias. O descanso também é produtivo.",
    "A criatividade flui abundantemente. Dedique-se a hobbies, explore novas formas de expressão e permita que sua imaginação voe alto.",
    "Relacionamentos em foco. Fortaleça laços com pessoas queridas e resolva pendências. A empatia será sua maior aliada.",
    "Semana de colheita e celebração. Reconheça seu progresso e comemore suas conquistas, por menores que pareçam. A gratidão atrai mais sucesso.",
    "Desafios podem surgir, mas encare-os como oportunidades de crescimento. Sua resiliência está em alta. Você é mais forte do que imagina.",
    "A energia favorece o aprendizado. Mergulhe em um novo livro, curso ou habilidade. O conhecimento adquirido agora será um diferencial.",
    "É hora de finalizar ciclos. Libere o que não serve mais para abrir espaço para o novo. O desapego trará leveza e novas perspectivas.",
];

export const getSkyOfTheWeek = (date: Date): string => {
    const weekNumber = getWeek(date);
    const index = weekNumber % SKY_OF_THE_WEEK_MESSAGES.length;
    return SKY_OF_THE_WEEK_MESSAGES[index];
};